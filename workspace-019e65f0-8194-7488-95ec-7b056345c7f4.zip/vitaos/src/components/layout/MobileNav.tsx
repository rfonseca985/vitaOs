'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import { useAuth } from '@/components/AuthProvider';
import { 
  LayoutDashboard, Calendar, Users, MessageSquare, 
  Video, Settings, Bot
} from 'lucide-react';

const patientNavItems = [
  { href: '/dashboard', icon: LayoutDashboard, label: 'Home' },
  { href: '/appointments', icon: Calendar, label: 'Consultas' },
  { href: '/doctors', icon: Users, label: 'Médicos' },
  { href: '/chat', icon: Bot, label: 'Chat IA' },
];

const doctorNavItems = [
  { href: '/dashboard', icon: LayoutDashboard, label: 'Home' },
  { href: '/appointments', icon: Calendar, label: 'Agenda' },
  { href: '/consultations', icon: Video, label: 'Consultas' },
  { href: '/chat', icon: Bot, label: 'vitasAI' },
];

export function MobileNav() {
  const pathname = usePathname();
  const { user } = useAuth();
  const isDoctor = user?.role === 'DOCTOR';
  const navItems = isDoctor ? doctorNavItems : patientNavItems;

  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 z-40 safe-area-bottom">
      <div className="flex items-center justify-around py-2">
        {navItems.map(item => {
          const isActive = pathname === item.href || pathname?.startsWith(item.href + '/');
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'flex flex-col items-center gap-1 px-3 py-2 rounded-lg transition-all min-w-[64px]',
                isActive ? 'text-primary' : 'text-slate-500'
              )}
            >
              <item.icon size={22} />
              <span className="text-[10px] font-medium">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}