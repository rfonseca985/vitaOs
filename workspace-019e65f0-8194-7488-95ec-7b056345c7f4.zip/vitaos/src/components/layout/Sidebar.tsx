'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useAuth } from '@/components/AuthProvider';
import { cn } from '@/lib/utils';
import { Avatar } from '@/components/ui/Avatar';
import { Badge } from '@/components/ui/Badge';
import { 
  LayoutDashboard, Calendar, Users, MessageSquare, 
  FileText, Pill, Settings, LogOut, Bell, Bot,
  ChevronLeft, ChevronRight, Video, Clock, Star
} from 'lucide-react';

const patientNavItems = [
  { href: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { href: '/appointments', icon: Calendar, label: 'Consultas' },
  { href: '/doctors', icon: Users, label: 'Médicos' },
  { href: '/chat', icon: MessageSquare, label: 'Chat vitasAI' },
  { href: '/records', icon: FileText, label: 'Prontuário' },
  { href: '/prescriptions', icon: Pill, label: 'Receitas' },
  { href: '/settings', icon: Settings, label: 'Configurações' },
];

const doctorNavItems = [
  { href: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { href: '/appointments', icon: Calendar, label: 'Agenda' },
  { href: '/consultations', icon: Video, label: 'Consultas' },
  { href: '/patients', icon: Users, label: 'Pacientes' },
  { href: '/chat', icon: Bot, label: 'vitasAI Assist' },
  { href: '/prescriptions', icon: Pill, label: 'Prescrições' },
  { href: '/settings', icon: Settings, label: 'Configurações' },
];

export function Sidebar() {
  const pathname = usePathname();
  const { user, doctor, logout } = useAuth();
  const isDoctor = user?.role === 'DOCTOR';
  const navItems = isDoctor ? doctorNavItems : patientNavItems;

  return (
    <aside className="hidden lg:flex flex-col w-64 bg-white border-r border-slate-200 min-h-screen fixed left-0 top-0 z-30">
      {/* Logo */}
      <div className="p-6 border-b border-slate-100">
        <Link href="/dashboard" className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-blue-700 flex items-center justify-center text-white font-bold text-lg">
            V
          </div>
          <div>
            <h1 className="font-bold text-slate-800 text-lg leading-tight">vitaOS</h1>
            <p className="text-xs text-slate-500">
              {isDoctor ? 'Área do Médico' : 'Área do Paciente'}
            </p>
          </div>
        </Link>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {navItems.map(item => {
          const isActive = pathname === item.href || pathname?.startsWith(item.href + '/');
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-150 font-medium',
                isActive
                  ? 'bg-primary/10 text-primary border-l-4 border-primary -ml-1 pl-5'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              )}
            >
              <item.icon size={20} />
              {item.label}
            </Link>
          );
        })}
      </nav>

      {/* Quick Stats */}
      {isDoctor && doctor && (
        <div className="p-4 mx-4 mb-4 rounded-xl bg-slate-50">
          <div className="flex items-center gap-2 mb-2">
            <Star className="w-4 h-4 text-warning fill-warning" />
            <span className="text-sm font-medium text-slate-700">
              {doctor.rating.toFixed(1)} ({doctor.reviewCount} avaliações)
            </span>
          </div>
          <div className="flex items-center gap-2 text-sm text-slate-500">
            <Clock className="w-4 h-4" />
            <span>{doctor.totalConsultations} consultas</span>
          </div>
        </div>
      )}

      {/* User Profile */}
      <div className="p-4 border-t border-slate-100">
        <div className="flex items-center gap-3 px-4 py-3 mb-2">
          <Avatar 
            src={user?.avatar} 
            name={user?.name || 'User'} 
            size="md" 
          />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-slate-800 truncate">
              {user?.name || 'Usuário'}
            </p>
            <p className="text-xs text-slate-500 truncate">
              {user?.email}
            </p>
          </div>
          <Badge variant={user?.isVerified ? 'success' : 'warning'}>
            {user?.isVerified ? 'Verificado' : 'Pendente'}
          </Badge>
        </div>
        <button
          onClick={logout}
          className="w-full flex items-center gap-3 px-4 py-2.5 rounded-lg text-slate-600 hover:bg-red-50 hover:text-red-600 transition-all text-sm font-medium"
        >
          <LogOut size={18} />
          Sair
        </button>
      </div>
    </aside>
  );
}