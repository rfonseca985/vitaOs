'use client';

import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { User, DoctorProfile, PatientProfile } from '@/types';
import { useAuthStore } from '@/store';
import toast from 'react-hot-toast';

interface AuthContextType {
  user: User | null;
  doctor: DoctorProfile | null;
  patient: PatientProfile | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  register: (data: RegisterData) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

interface RegisterData {
  email: string;
  password: string;
  name: string;
  phone: string;
  dateOfBirth: string;
  cpf: string;
  role: 'PATIENT' | 'DOCTOR';
  crm?: string;
  crmState?: string;
  specialty?: string;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const { user, doctor, patient, isLoading, isAuthenticated, setUser, setDoctor, setPatient, setLoading, logout: logoutStore } = useAuthStore();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    refreshUser();
  }, []);

  const refreshUser = async () => {
    try {
      const res = await fetch('/api/auth/me');
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
        if (data.doctor) setDoctor(data.doctor);
        if (data.patient) setPatient(data.patient);
      } else {
        setUser(null);
        setDoctor(null);
        setPatient(null);
      }
    } catch (error) {
      console.error('Failed to fetch user:', error);
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  const login = async (email: string, password: string) => {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();

      if (res.ok) {
        setUser(data.user);
        if (data.doctor) setDoctor(data.doctor);
        if (data.patient) setPatient(data.patient);
        toast.success('Login realizado com sucesso!');
        return { success: true };
      }

      return { success: false, error: data.error || 'Erro ao fazer login' };
    } catch (error) {
      console.error('Login error:', error);
      return { success: false, error: 'Erro de conexão. Tente novamente.' };
    }
  };

  const register = async (data: RegisterData) => {
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      const response = await res.json();

      if (res.ok) {
        setUser(response.user);
        if (response.doctor) setDoctor(response.doctor);
        if (response.patient) setPatient(response.patient);
        toast.success('Conta criada com sucesso!');
        return { success: true };
      }

      return { success: false, error: response.error || 'Erro ao criar conta' };
    } catch (error) {
      console.error('Register error:', error);
      return { success: false, error: 'Erro de conexão. Tente novamente.' };
    }
  };

  const logout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
      logoutStore();
      toast.success('Você saiu da sua conta');
    } catch (error) {
      console.error('Logout error:', error);
      logoutStore();
    }
  };

  // Prevent hydration issues
  if (!mounted) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-blue-700 flex items-center justify-center text-white font-bold text-2xl animate-pulse">
            V
          </div>
          <div className="flex gap-1.5">
            {[0, 1, 2].map(i => (
              <div
                key={i}
                className="w-2 h-2 rounded-full bg-primary animate-bounce"
                style={{ animationDelay: `${i * 150}ms` }}
              />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <AuthContext.Provider 
      value={{ 
        user, 
        doctor, 
        patient, 
        isLoading, 
        isAuthenticated, 
        login, 
        register, 
        logout, 
        refreshUser 
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}