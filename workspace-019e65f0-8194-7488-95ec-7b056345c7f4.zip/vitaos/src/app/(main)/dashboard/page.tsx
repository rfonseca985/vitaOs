'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useAuth } from '@/components/AuthProvider';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { Avatar } from '@/components/ui/Avatar';
import { Skeleton } from '@/components/ui/Skeleton';
import { Appointment, DoctorProfile } from '@/types';
import { formatDate, formatTime, formatRelativeTime, formatCurrency } from '@/lib/utils';
import { 
  Calendar, Clock, Video, Star, Users, Activity, 
  Bot, FileText, Pill, Plus, ArrowRight, CheckCircle,
  TrendingUp, AlertCircle
} from 'lucide-react';

export default function DashboardPage() {
  const { user, doctor } = useAuth();
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const isDoctor = user?.role === 'DOCTOR';

  useEffect(() => {
    fetchAppointments();
  }, []);

  const fetchAppointments = async () => {
    try {
      const res = await fetch('/api/appointments?upcoming=true&limit=5');
      if (res.ok) {
        const data = await res.json();
        setAppointments(data.appointments);
      }
    } catch (error) {
      console.error('Failed to fetch appointments:', error);
    } finally {
      setLoading(false);
    }
  };

  // Stats based on user role
  const stats = isDoctor ? [
    { label: 'Consultas Hoje', value: '3', icon: Calendar, color: 'primary' },
    { label: 'Total Pacientes', value: doctor?.totalConsultations || '0', icon: Users, color: 'secondary' },
    { label: 'Avaliação', value: (doctor?.rating || 0).toFixed(1), icon: Star, color: 'warning' },
    { label: 'Receita Mensal', value: 'R$ 0', icon: TrendingUp, color: 'accent' },
  ] : [
    { label: 'Próxima Consulta', value: appointments[0] ? formatDate(appointments[0].scheduledAt) : 'Nenhuma', icon: Calendar, color: 'primary' },
    { label: 'Consultas Realizadas', value: '2', icon: CheckCircle, color: 'secondary' },
    { label: 'Médicos Favoritos', value: '1', icon: Star, color: 'warning' },
    { label: 'Prontuário', value: 'Atualizado', icon: FileText, color: 'accent' },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Welcome Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-slate-900">
            Olá, {user?.name?.split(' ')[0]}! 👋
          </h1>
          <p className="text-slate-500 mt-1">
            {isDoctor 
              ? 'Aqui está um resumo do seu dia'
              : 'Aqui está seu resumo de saúde'
            }
          </p>
        </div>
        
        <div className="flex gap-3">
          {isDoctor ? (
            <Link href="/appointments">
              <Button>
                <Calendar className="w-4 h-4" />
                Ver Agenda
              </Button>
            </Link>
          ) : (
            <>
              <Link href="/chat">
                <Button variant="outline">
                  <Bot className="w-4 h-4" />
                  Chat vitasAI
                </Button>
              </Link>
              <Link href="/doctors">
                <Button>
                  <Plus className="w-4 h-4" />
                  Agendar Consulta
                </Button>
              </Link>
            </>
          )}
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <Card key={stat.label} className="animate-slide-up" style={{ animationDelay: `${index * 50}ms` }}>
            <div className="flex items-center gap-4">
              <div className={`w-12 h-12 rounded-xl bg-${stat.color}/10 flex items-center justify-center`}>
                <stat.icon className={`w-6 h-6 text-${stat.color}`} />
              </div>
              <div>
                <p className="text-2xl font-bold text-slate-900">{stat.value}</p>
                <p className="text-sm text-slate-500">{stat.label}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Upcoming Appointments */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-primary" />
                <CardTitle>
                  {isDoctor ? 'Próximas Consultas' : 'Suas Próximas Consultas'}
                </CardTitle>
              </div>
              <Link href="/appointments" className="text-sm text-primary hover:underline flex items-center gap-1">
                Ver todas <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </CardHeader>
          
          <CardContent>
            {loading ? (
              <div className="space-y-4">
                {[1, 2, 3].map(i => (
                  <div key={i} className="flex items-center gap-4 p-4 rounded-xl bg-slate-50">
                    <Skeleton variant="circular" width={48} height={48} />
                    <div className="flex-1 space-y-2">
                      <Skeleton variant="text" width="60%" />
                      <Skeleton variant="text" width="40%" />
                    </div>
                  </div>
                ))}
              </div>
            ) : appointments.length > 0 ? (
              <div className="space-y-4">
                {appointments.slice(0, 4).map((apt) => {
                  const otherPerson = isDoctor ? apt.patient?.user : apt.doctor?.user;
                  return (
                    <div 
                      key={apt.id}
                      className="flex items-center gap-4 p-4 rounded-xl bg-slate-50 hover:bg-slate-100 transition-colors"
                    >
                      <Avatar src={otherPerson?.avatar} name={otherPerson?.name || 'User'} size="lg" />
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-slate-900 truncate">
                          {otherPerson?.name}
                        </p>
                        <div className="flex items-center gap-2 text-sm text-slate-500 mt-1">
                          <Clock className="w-4 h-4" />
                          {formatDate(apt.scheduledAt)} às {formatTime(apt.scheduledAt)}
                        </div>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant={apt.type === 'VIDEO' ? 'primary' : 'default'}>
                            {apt.type === 'VIDEO' && <Video className="w-3 h-3 mr-1" />}
                            {apt.type === 'VIDEO' ? 'Video' : apt.type === 'CHAT' ? 'Chat' : 'Telefone'}
                          </Badge>
                          <Badge variant="success">Agendada</Badge>
                        </div>
                      </div>
                      <Link href={`/consultations/${apt.id}`}>
                        <Button size="sm">
                          Ver
                        </Button>
                      </Link>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8">
                <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Calendar className="w-8 h-8 text-slate-400" />
                </div>
                <p className="text-slate-500 mb-4">Nenhuma consulta agendada</p>
                {!isDoctor && (
                  <Link href="/doctors">
                    <Button>
                      <Plus className="w-4 h-4" />
                      Agendar Consulta
                    </Button>
                  </Link>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quick Actions / AI Assistant */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Bot className="w-5 h-5 text-accent" />
              <CardTitle>vitasAI - Assistente de Saúde</CardTitle>
            </div>
            <CardDescription>
              Tire dúvidas sobre saúde e receba orientações
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            <div className="bg-gradient-to-r from-accent/10 to-purple-50 rounded-xl p-4 mb-4">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-full bg-accent/20 flex items-center justify-center flex-shrink-0">
                  <Bot className="w-5 h-5 text-accent" />
                </div>
                <div>
                  <p className="font-medium text-slate-800 text-sm">Olá! Sou a vitasAI 👋</p>
                  <p className="text-sm text-slate-600 mt-1">
                    Posso ajudar com triagem de sintomas, informações sobre medicamentos e muito mais.
                    Como posso ajudar hoje?
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <Link href="/chat?mode=symptoms">
                <button className="w-full p-4 rounded-xl border border-slate-200 hover:border-primary hover:bg-primary/5 transition-all text-left">
                  <Activity className="w-6 h-6 text-primary mb-2" />
                  <p className="font-medium text-slate-800 text-sm">Triagem de Sintomas</p>
                  <p className="text-xs text-slate-500">Avalie seus sintomas</p>
                </button>
              </Link>
              
              <Link href="/chat?mode=info">
                <button className="w-full p-4 rounded-xl border border-slate-200 hover:border-primary hover:bg-primary/5 transition-all text-left">
                  <FileText className="w-6 h-6 text-secondary mb-2" />
                  <p className="font-medium text-slate-800 text-sm">Informações Médicas</p>
                  <p className="text-xs text-slate-500">Saiba mais sobre doenças</p>
                </button>
              </Link>
              
              <Link href="/chat?mode=medications">
                <button className="w-full p-4 rounded-xl border border-slate-200 hover:border-primary hover:bg-primary/5 transition-all text-left">
                  <Pill className="w-6 h-6 text-warning mb-2" />
                  <p className="font-medium text-slate-800 text-sm">Medicamentos</p>
                  <p className="text-xs text-slate-500">Informações sobre remédios</p>
                </button>
              </Link>
              
              <Link href="/chat?mode=appointments">
                <button className="w-full p-4 rounded-xl border border-slate-200 hover:border-primary hover:bg-primary/5 transition-all text-left">
                  <Calendar className="w-6 h-6 text-accent mb-2" />
                  <p className="font-medium text-slate-800 text-sm">Agendar Consulta</p>
                  <p className="text-xs text-slate-500">Marque uma consulta</p>
                </button>
              </Link>
            </div>

            <Link href="/chat" className="block mt-4">
              <Button fullWidth variant="outline">
                <Bot className="w-4 h-4" />
                Abrir Chat com vitasAI
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>

      {/* Health Tips / Medical Info */}
      <Card className="bg-gradient-to-r from-secondary/10 to-emerald-50 border-secondary/20">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-secondary/20 flex items-center justify-center flex-shrink-0">
            <AlertCircle className="w-7 h-7 text-secondary" />
          </div>
          <div>
            <h3 className="font-semibold text-slate-900">Dica de Saúde 💡</h3>
            <p className="text-sm text-slate-600 mt-1">
              Beber água regularmente melhora a concentração e ajuda a manter o corpo saudável. 
              A recomendação é de pelo menos 2 litros por dia para adultos.
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
}