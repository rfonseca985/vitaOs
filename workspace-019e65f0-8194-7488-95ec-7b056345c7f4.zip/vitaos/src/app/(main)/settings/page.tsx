'use client';

import { useState } from 'react';
import { useAuth } from '@/components/AuthProvider';
import { Card, CardHeader, CardTitle, CardDescription } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Select } from '@/components/ui/Select';
import { Badge } from '@/components/ui/Badge';
import { Avatar } from '@/components/ui/Avatar';
import { formatDate } from '@/lib/utils';
import toast from 'react-hot-toast';
import { 
  User, Shield, Bell, Database, Globe, Moon,
  LogOut, Camera, Download, Trash2, Check, Key
} from 'lucide-react';

export default function SettingsPage() {
  const { user, doctor, patient, logout } = useAuth();
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  
  // Profile form
  const [name, setName] = useState(user?.name || '');
  const [phone, setPhone] = useState(user?.phone || '');

  const isDoctor = user?.role === 'DOCTOR';

  const handleSave = async () => {
    setSaving(true);
    // Simulate save
    await new Promise(resolve => setTimeout(resolve, 1000));
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
    toast.success('Alterações salvas com sucesso!');
  };

  const handleExportData = async () => {
    try {
      // In production, this would call an API to get all user data
      const data = {
        exportDate: new Date().toISOString(),
        user: { email: user?.email, name: user?.name },
        doctor: doctor,
        patient: patient,
      };

      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `vitaos-data-${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success('Dados exportados com sucesso!');
    } catch (error) {
      toast.error('Erro ao exportar dados');
    }
  };

  const settingsSections = [
    { id: 'profile', icon: User, label: 'Perfil' },
    { id: 'security', icon: Shield, label: 'Segurança' },
    { id: 'notifications', icon: Bell, label: 'Notificações' },
    { id: 'data', icon: Database, label: 'Dados' },
  ];

  return (
    <div className="space-y-6 animate-fade-in max-w-4xl mx-auto">
      {/* Header */}
      <div>
        <h1 className="text-2xl md:text-3xl font-bold text-slate-900">
          Configurações
        </h1>
        <p className="text-slate-500 mt-1">
          Gerencie sua conta e preferências
        </p>
      </div>

      {/* Profile Section */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
              <User className="w-5 h-5 text-primary" />
            </div>
            <div>
              <CardTitle>Perfil</CardTitle>
              <CardDescription>Suas informações pessoais</CardDescription>
            </div>
          </div>
        </CardHeader>

        <div className="p-6 pt-0 space-y-6">
          {/* Avatar */}
          <div className="flex items-center gap-6">
            <div className="relative">
              <Avatar src={user?.avatar} name={user?.name || 'User'} size="xl" />
              <button className="absolute bottom-0 right-0 w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center hover:bg-primary-dark transition-colors">
                <Camera className="w-4 h-4" />
              </button>
            </div>
            <div>
              <p className="font-medium text-slate-900">{user?.name}</p>
              <p className="text-sm text-slate-500">{user?.email}</p>
              <Badge variant={user?.isVerified ? 'success' : 'warning'} className="mt-2">
                {user?.isVerified ? 'Conta verificada' : 'Conta não verificada'}
              </Badge>
            </div>
          </div>

          {/* Form */}
          <div className="grid md:grid-cols-2 gap-6">
            <Input
              label="Nome completo"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Seu nome"
            />
            <Input
              label="Telefone"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="(11) 99999-9999"
            />
            <Input
              label="Email"
              value={user?.email || ''}
              disabled
              helper="Email não pode ser alterado"
            />
            <Input
              label="Data de cadastro"
              value={user?.createdAt ? formatDate(user.createdAt) : '-'}
              disabled
            />
          </div>

          {/* Doctor specific */}
          {isDoctor && doctor && (
            <div className="pt-4 border-t border-slate-100">
              <h4 className="font-medium text-slate-900 mb-4">Informações Profissionais</h4>
              <div className="grid md:grid-cols-2 gap-6">
                <Input
                  label="CRM"
                  value={`${doctor.crm}-${doctor.crmState}`}
                  disabled
                />
                <Input
                  label="Especialidade"
                  value={doctor.specialty}
                  disabled
                />
                <Input
                  label="Valor da consulta"
                  value={`R$ ${doctor.consultationPrice.toFixed(2)}`}
                  disabled
                />
                <Input
                  label="Duração padrão"
                  value={`${doctor.consultationDuration} minutos`}
                  disabled
                />
              </div>
            </div>
          )}

          <div className="pt-4">
            <Button onClick={handleSave} loading={saving}>
              {saved ? <><Check className="w-4 h-4" /> Salvo!</> : 'Salvar Alterações'}
            </Button>
          </div>
        </div>
      </Card>

      {/* Security Section */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-secondary/10 flex items-center justify-center">
              <Shield className="w-5 h-5 text-secondary" />
            </div>
            <div>
              <CardTitle>Segurança</CardTitle>
              <CardDescription>Proteja sua conta</CardDescription>
            </div>
          </div>
        </CardHeader>

        <div className="p-6 pt-0 space-y-4">
          <div className="flex items-center justify-between p-4 rounded-xl bg-slate-50">
            <div className="flex items-center gap-3">
              <Key className="w-5 h-5 text-slate-600" />
              <div>
                <p className="font-medium text-slate-900">Alterar senha</p>
                <p className="text-sm text-slate-500">Última alteração: há 30 dias</p>
              </div>
            </div>
            <Button variant="secondary" size="sm">
              Alterar
            </Button>
          </div>

          <div className="flex items-center justify-between p-4 rounded-xl bg-slate-50">
            <div className="flex items-center gap-3">
              <Shield className="w-5 h-5 text-slate-600" />
              <div>
                <p className="font-medium text-slate-900">Autenticação em dois fatores</p>
                <p className="text-sm text-slate-500">Adicione uma camada extra de segurança</p>
              </div>
            </div>
            <Button variant="secondary" size="sm">
              Ativar
            </Button>
          </div>

          <div className="flex items-center justify-between p-4 rounded-xl bg-slate-50">
            <div className="flex items-center gap-3">
              <Globe className="w-5 h-5 text-slate-600" />
              <div>
                <p className="font-medium text-slate-900">Sessões ativas</p>
                <p className="text-sm text-slate-500">1 sessão ativa agora</p>
              </div>
            </div>
            <Button variant="ghost" size="sm">
              Ver todas
            </Button>
          </div>
        </div>
      </Card>

      {/* Notifications Section */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-warning/10 flex items-center justify-center">
              <Bell className="w-5 h-5 text-warning" />
            </div>
            <div>
              <CardTitle>Notificações</CardTitle>
              <CardDescription>Escolha como deseja ser notificado</CardDescription>
            </div>
          </div>
        </CardHeader>

        <div className="p-6 pt-0 space-y-4">
          {[
            { label: 'Lembretes de consulta', desc: 'Receba notificações antes das suas consultas', enabled: true },
            { label: 'Novas mensagens', desc: 'Seja notificado quando receber mensagens', enabled: true },
            { label: 'Resultados de exames', desc: 'Receba alertas quando novos resultados estiverem disponíveis', enabled: false },
            { label: 'Promoções e novidades', desc: 'Stay updated on new features and special offers', enabled: false },
          ].map((item, i) => (
            <div key={i} className="flex items-center justify-between p-4 rounded-xl bg-slate-50">
              <div>
                <p className="font-medium text-slate-900">{item.label}</p>
                <p className="text-sm text-slate-500">{item.desc}</p>
              </div>
              <button 
                className={`relative w-11 h-6 rounded-full transition-colors ${
                  item.enabled ? 'bg-primary' : 'bg-slate-300'
                }`}
              >
                <span className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-transform ${
                  item.enabled ? 'right-1' : 'left-1'
                }`} />
              </button>
            </div>
          ))}
        </div>
      </Card>

      {/* Data Section */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-accent/10 flex items-center justify-center">
              <Database className="w-5 h-5 text-accent" />
            </div>
            <div>
              <CardTitle>Seus Dados</CardTitle>
              <CardDescription>Gerencie suas informações</CardDescription>
            </div>
          </div>
        </CardHeader>

        <div className="p-6 pt-0 space-y-4">
          <div className="flex items-center justify-between p-4 rounded-xl bg-slate-50">
            <div className="flex items-center gap-3">
              <Download className="w-5 h-5 text-slate-600" />
              <div>
                <p className="font-medium text-slate-900">Exportar dados</p>
                <p className="text-sm text-slate-500">Baixe uma cópia de todos os seus dados</p>
              </div>
            </div>
            <Button variant="secondary" size="sm" onClick={handleExportData}>
              Exportar JSON
            </Button>
          </div>

          <div className="flex items-center justify-between p-4 rounded-xl bg-error/5 border border-error/20">
            <div className="flex items-center gap-3">
              <Trash2 className="w-5 h-5 text-error" />
              <div>
                <p className="font-medium text-error">Excluir conta</p>
                <p className="text-sm text-slate-500">Remova permanentemente sua conta e todos os dados</p>
              </div>
            </div>
            <Button variant="danger" size="sm">
              Excluir Conta
            </Button>
          </div>
        </div>
      </Card>

      {/* Logout */}
      <Card className="border-red-100">
        <div className="flex items-center justify-between p-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-100 flex items-center justify-center">
              <LogOut className="w-5 h-5 text-error" />
            </div>
            <div>
              <p className="font-medium text-slate-900">Sair da conta</p>
              <p className="text-sm text-slate-500">Encerre sua sessão neste dispositivo</p>
            </div>
          </div>
          <Button variant="danger" onClick={logout}>
            <LogOut className="w-4 h-4" />
            Sair
          </Button>
        </div>
      </Card>
    </div>
  );
}