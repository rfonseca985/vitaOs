'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Card, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Select } from '@/components/ui/Select';
import { Badge } from '@/components/ui/Badge';
import { Avatar } from '@/components/ui/Avatar';
import { Skeleton } from '@/components/ui/Skeleton';
import { DoctorProfile } from '@/types';
import { formatCurrency, SPECIALTY_ICONS } from '@/lib/utils';
import { 
  Search, MapPin, Star, Clock, Video, Calendar, 
  Filter, SlidersHorizontal, Stethoscope
} from 'lucide-react';

const SPECIALTIES = [
  'Todas', 'Clínica Geral', 'Cardiologia', 'Dermatologia', 'Endocrinologia',
  'Gastroenterologia', 'Neurologia', 'Ortopedia', 'Oftalmologia',
  'Pediatria', 'Psiquiatria', 'Ginecologia', 'Urologia',
];

interface DoctorWithUser extends DoctorProfile {
  user: {
    id: string;
    name: string;
    email: string;
    avatar: string | null;
    isVerified: boolean;
  };
}

export default function DoctorsPage() {
  const [doctors, setDoctors] = useState<DoctorWithUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [specialty, setSpecialty] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const router = useRouter();

  useEffect(() => {
    fetchDoctors();
  }, [specialty, search]);

  const fetchDoctors = async () => {
    try {
      const params = new URLSearchParams();
      if (specialty && specialty !== 'Todas') params.set('specialty', specialty);
      if (search) params.set('search', search);

      const res = await fetch(`/api/doctors?${params.toString()}`);
      if (res.ok) {
        const data = await res.json();
        setDoctors(data.doctors);
      }
    } catch (error) {
      console.error('Failed to fetch doctors:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    fetchDoctors();
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-2xl md:text-3xl font-bold text-slate-900">
          Encontre seu Médico
        </h1>
        <p className="text-slate-500 mt-1">
          Busque por especialidade e encontre o profissional ideal para você
        </p>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col md:flex-row gap-4">
        <form onSubmit={handleSearch} className="flex-1">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
            <input
              type="text"
              placeholder="Buscar por nome ou especialidade..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-12 pr-4 py-3 rounded-xl border border-slate-200 bg-white text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
            />
          </div>
        </form>

        <Select
          value={specialty}
          onChange={(e) => setSpecialty(e.target.value)}
          options={SPECIALTIES.map(s => ({ value: s === 'Todas' ? '' : s, label: s }))}
          placeholder="Especialidade"
          className="md:w-48"
        />

        <Button 
          variant="outline" 
          onClick={() => setShowFilters(!showFilters)}
          className="md:hidden"
        >
          <SlidersHorizontal className="w-4 h-4" />
          Filtros
        </Button>
      </div>

      {/* Results Count */}
      <div className="text-sm text-slate-500">
        {loading ? 'Buscando...' : `${doctors.length} médicos encontrados`}
      </div>

      {/* Doctors Grid */}
      {loading ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <Card key={i} className="p-6">
              <div className="flex items-start gap-4 mb-4">
                <Skeleton variant="circular" width={64} height={64} />
                <div className="flex-1 space-y-2">
                  <Skeleton variant="text" width="70%" />
                  <Skeleton variant="text" width="50%" />
                </div>
              </div>
              <Skeleton variant="rectangular" height={80} className="mb-4" />
              <Skeleton variant="rectangular" height={40} />
            </Card>
          ))}
        </div>
      ) : doctors.length > 0 ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {doctors.map((doc, index) => (
            <Card 
              key={doc.id} 
              hover 
              className="animate-slide-up overflow-hidden"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              {/* Top Banner */}
              <div className="h-2 bg-gradient-to-r from-primary to-blue-600" />
              
              <div className="p-6">
                {/* Doctor Info */}
                <div className="flex items-start gap-4 mb-4">
                  <Avatar 
                    src={doc.user.avatar} 
                    name={doc.user.name} 
                    size="lg"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-slate-900 truncate">
                        {doc.user.name}
                      </h3>
                      {doc.user.isVerified && (
                        <Badge variant="success" size="sm">Verificado</Badge>
                      )}
                    </div>
                    <p className="text-sm text-primary font-medium">{doc.specialty}</p>
                    <div className="flex items-center gap-2 mt-1 text-sm text-slate-500">
                      <MapPin className="w-4 h-4" />
                      <span>{doc.crmState}</span>
                    </div>
                  </div>
                </div>

                {/* Stats */}
                <div className="flex items-center gap-4 mb-4 p-3 rounded-xl bg-slate-50">
                  <div className="flex items-center gap-1.5">
                    <Star className="w-4 h-4 text-warning fill-warning" />
                    <span className="font-semibold text-slate-900">{doc.rating.toFixed(1)}</span>
                    <span className="text-sm text-slate-500">({doc.reviewCount})</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-slate-500 text-sm">
                    <Stethoscope className="w-4 h-4" />
                    <span>{doc.totalConsultations} consultas</span>
                  </div>
                </div>

                {/* Bio */}
                {doc.bio && (
                  <p className="text-sm text-slate-600 line-clamp-2 mb-4">
                    {doc.bio}
                  </p>
                )}

                {/* Price and Action */}
                <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                  <div>
                    <p className="text-sm text-slate-500">Consulta</p>
                    <p className="text-xl font-bold text-slate-900">
                      {formatCurrency(doc.consultationPrice)}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="secondary" size="sm">
                      <Video className="w-4 h-4" />
                      Agendar
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="text-center py-12">
          <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Stethoscope className="w-8 h-8 text-slate-400" />
          </div>
          <h3 className="font-semibold text-slate-800 mb-2">Nenhum médico encontrado</h3>
          <p className="text-slate-500 text-sm mb-4">
            Tente buscar com outros termos ou filtres
          </p>
          <Button onClick={() => { setSearch(''); setSpecialty(''); }}>
            Limpar Filtros
          </Button>
        </Card>
      )}

      {/* CTA */}
      <Card className="bg-gradient-to-r from-primary to-blue-600 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-semibold text-lg">Não encontrou o que procura?</h3>
            <p className="text-white/80 text-sm mt-1">
              Nossa equipe pode ajudar a encontrar o médico ideal para você
            </p>
          </div>
          <Button variant="secondary" className="bg-white/20 text-white hover:bg-white/30 border-0">
            <Calendar className="w-4 h-4" />
            Falar com Suporte
          </Button>
        </div>
      </Card>
    </div>
  );
}