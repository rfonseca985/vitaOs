'use client';

import { useState, useEffect, useRef } from 'react';
import { useSearchParams } from 'next/navigation';
import { useAuth } from '@/components/AuthProvider';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import toast from 'react-hot-toast';
import { 
  Bot, Send, Sparkles, AlertCircle, Clock, 
  Activity, Pill, Calendar, Lightbulb, X, Copy,
  ThumbsUp, ThumbsDown
} from 'lucide-react';

interface Message {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: Date;
}

const quickActions = [
  { icon: Activity, label: 'Triagem de Sintomas', mode: 'symptoms', color: 'primary' },
  { icon: Pill, label: 'Informações sobre Medicamentos', mode: 'medications', color: 'secondary' },
  { icon: Lightbulb, label: 'Dicas de Saúde', mode: 'health-tips', color: 'warning' },
  { icon: Calendar, label: 'Agendar Consulta', mode: 'appointments', color: 'accent' },
];

const symptomOptions = [
  'Dor de cabeça', 'Febre', 'Tosse', 'Dor abdominal',
  'Náusea', 'Cansaço', 'Dor muscular', 'Falta de ar',
  'Tontura', 'Insônia', 'Ansiedade', 'Dor nas costas',
];

export default function ChatPage() {
  const { user, isAuthenticated } = useAuth();
  const searchParams = useSearchParams();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [mode, setMode] = useState(searchParams.get('mode') || 'general');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Initial greeting message
    setMessages([
      {
        id: '1',
        role: 'assistant',
        content: `Olá! Sou a **vitasAI**, sua assistente de saúde virtual do vitaOS. 🌿\n\nPosso ajudá-lo com:\n• Triagem de sintomas\n• Informações sobre medicamentos\n• Dicas de saúde e bem-estar\n• Orientações sobre quando procurar atendimento médico\n\n**Lembre-se:** Sou uma assistente e não substituo o advice médico profissional. Para diagnósticos e tratamentos, sempre consulte um médico.\n\nComo posso ajudar você hoje?`,
        timestamp: new Date(),
      },
    ]);
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: messages.map(m => ({ role: m.role, content: m.content })),
          type: mode,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const assistantMessage: Message = {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          content: data.response,
          timestamp: new Date(),
        };
        setMessages(prev => [...prev, assistantMessage]);
      } else {
        throw new Error('Failed to get response');
      }
    } catch (error) {
      toast.error('Erro ao processar mensagem. Tente novamente.');
      // Add error message
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: '❌ Desculpe, estou com dificuldades para responder agora. Tente novamente em alguns instantes.',
        timestamp: new Date(),
      }]);
    } finally {
      setLoading(false);
    }
  };

  const handleQuickAction = (actionMode: string) => {
    setMode(actionMode);
    const action = quickActions.find(a => a.mode === actionMode);
    if (action) {
      setInput(`Quero saber mais sobre: ${action.label}`);
    }
  };

  const copyToClipboard = (content: string) => {
    navigator.clipboard.writeText(content);
    toast.success('Copiado para a área de transferência');
  };

  return (
    <div className="h-[calc(100vh-8rem)] flex flex-col animate-fade-in">
      {/* Header */}
      <div className="mb-4">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-accent to-purple-600 flex items-center justify-center">
            <Bot className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">vitasAI</h1>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-secondary animate-pulse" />
              <span className="text-sm text-slate-500">Online</span>
            </div>
          </div>
        </div>
        <p className="text-slate-600">
          Sua assistente de saúde virtual. Tire dúvidas e receba orientações.
        </p>
      </div>

      {/* Disclaimer */}
      <div className="mb-4 p-3 rounded-xl bg-warning/10 border border-warning/20 flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-warning flex-shrink-0 mt-0.5" />
        <p className="text-sm text-slate-700">
          <strong>Aviso:</strong> vitasAI é uma ferramenta de triagem e informação, não substitui 
          konsultasi médica profissional. Em caso de emergência, procure atendimento médico imediato.
        </p>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto space-y-4 mb-4 pr-2">
        {messages.map((message) => (
          <div 
            key={message.id}
            className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div 
              className={`max-w-[85%] md:max-w-[75%] ${
                message.role === 'user' 
                  ? 'bg-primary text-white' 
                  : 'bg-white border border-slate-200'
              } rounded-2xl p-4 shadow-sm`}
            >
              {message.role === 'assistant' && (
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center">
                    <Sparkles className="w-3 h-3 text-accent" />
                  </div>
                  <span className="text-xs font-medium text-accent">vitasAI</span>
                </div>
              )}
              
              <div className={`text-sm leading-relaxed whitespace-pre-wrap ${
                message.role === 'user' ? 'text-white' : 'text-slate-700'
              }`}>
                {message.content.split('\n').map((line, i) => {
                  // Handle markdown bold
                  if (line.includes('**')) {
                    const parts = line.split('**');
                    return (
                      <p key={i}>
                        {parts.map((part, j) => 
                          j % 2 === 1 ? <strong key={j}>{part}</strong> : part
                        )}
                      </p>
                    );
                  }
                  return <p key={i}>{line}</p>;
                })}
              </div>

              <div className={`flex items-center justify-between mt-3 pt-2 border-t ${
                message.role === 'user' ? 'border-white/20' : 'border-slate-100'
              }`}>
                <span className={`text-xs ${
                  message.role === 'user' ? 'text-white/70' : 'text-slate-400'
                }`}>
                  {message.timestamp.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                </span>
                
                {message.role === 'assistant' && (
                  <button 
                    onClick={() => copyToClipboard(message.content)}
                    className="text-xs text-slate-400 hover:text-slate-600 flex items-center gap-1"
                  >
                    <Copy className="w-3 h-3" />
                    Copiar
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}

        {/* Typing indicator */}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center">
                  <Sparkles className="w-3 h-3 text-accent" />
                </div>
                <span className="text-xs font-medium text-accent">vitasAI digitando...</span>
              </div>
              <div className="ai-typing flex gap-1.5 pl-8">
                <span></span>
                <span></span>
                <span></span>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Quick Actions */}
      {messages.length <= 1 && (
        <div className="mb-4">
          <p className="text-sm text-slate-500 mb-3">Ações rápidas:</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {quickActions.map((action) => (
              <button
                key={action.mode}
                onClick={() => handleQuickAction(action.mode)}
                className={`p-4 rounded-xl border border-slate-200 hover:border-${action.color} hover:bg-${action.color}/5 transition-all text-left`}
              >
                <action.icon className={`w-6 h-6 text-${action.color} mb-2`} />
                <p className="text-sm font-medium text-slate-800">{action.label}</p>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input */}
      <div className="flex gap-3">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Digite sua mensagem..."
          className="flex-1 px-4 py-3 rounded-xl border border-slate-200 bg-white text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
          disabled={loading}
        />
        <Button 
          onClick={handleSend}
          disabled={!input.trim() || loading}
          loading={loading}
        >
          <Send className="w-5 h-5" />
        </Button>
      </div>

      {/* Suggestions when empty */}
      {messages.length === 1 && (
        <div className="mt-4 p-4 rounded-xl bg-slate-50">
          <p className="text-sm text-slate-500 mb-3">Sugestões:</p>
          <div className="flex flex-wrap gap-2">
            {symptomOptions.slice(0, 6).map((symptom) => (
              <button
                key={symptom}
                onClick={() => {
                  setInput(`Estou sentindo ${symptom.toLowerCase()}. O que devo fazer?`);
                }}
                className="px-3 py-1.5 rounded-full bg-white border border-slate-200 text-sm text-slate-600 hover:border-primary hover:text-primary transition-colors"
              >
                {symptom}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}