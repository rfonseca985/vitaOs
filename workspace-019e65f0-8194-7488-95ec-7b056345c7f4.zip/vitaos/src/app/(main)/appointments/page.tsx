'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useAuth } from '@/components/AuthProvider';
import { Card, CardHeader, CardTitle, CardDescription } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { Avatar } from '@/components/ui/Avatar';
import { Modal, ModalFooter } from '@/components/ui/Modal';
import { Skeleton } from '@/components/ui/Skeleton';
import { Appointment } from '@/types';
import { formatDate, formatTime, formatRelativeTime } from '@/lib/utils';
import { 
  Calendar, Clock, Video, Phone, MessageSquare, Plus,
  CheckCircle, XCircle, AlertCircle, Play, ArrowRight,
  CalendarDays, Filter
} from 'lucide-react';

type TabType = 'upcoming' | 'completed' | 'cancelled';

export default function AppointmentsPage() {
  const { user } = useAuth();
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<TabType>('upcoming');
  const [cancelModal, setCancelModal] = useState<string | null>(null);
  const [cancelling, setCancelling] = useState(false);
  const isDoctor = user?.role === 'DOCTOR';

  useEffect(() => {
    fetchAppointments();
  }, [activeTab]);

  const fetchAppointments = async () => {
    try {
      const params = new URLSearchParams();
      if (activeTab === 'upcoming') {
        params.set('upcoming', 'true');
      } else {
        params.set('status', activeTab.toUpperCase());
      }

      const res = await fetch(`/api/appointments?${params.toString()}`);
      if (res.ok) {
        const data = await res.json();
        setAppointments(data.appointments);
      }
    } catch (error) {
      console.error('Failed to fetch appointments:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = async (id: string) => {
    setCancelling(true);
    try {
      // In a real app, this would call an API
      // For now, just close the modal
      setCancelModal(null);
    } catch (error) {
      console.error('Cancel error:', error);
    } finally {
      setCancelling(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'SCHEDULED':
        return <Badge variant="primary">Agendada</Badge>;
      case 'IN_PROGRESS':
        return <Badge variant="warning">Em Andamento</Badge>;
      case 'COMPLETED':
        return <Badge variant="success">Concluída</Badge>;
      case 'CANCELLED':
        return <Badge variant="error">Cancelada</Badge>;
      default:
        return <Badge variant="default">{status}</Badge>;
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'VIDEO':
        return <Video className="w-4 h-4" />;
      case 'PHONE':
        return <Phone className="w-4 h-4" />;
      default:
        return <MessageSquare className="w-4 h-4" />;
    }
  };

  const canJoinCall = (apt: Appointment) => {
    const now = new Date();
    const aptTime = new Date(apt.scheduledAt);
    const diff = aptTime.getTime() - now.getTime();
    // Can join 10 minutes before and during the appointment
    return diff < 10 * 60 * 1000 && apt.status === 'SCHEDULED';
  };

  const tabs = [
    { id: 'upcoming' as TabType, label: 'Próximas', icon: CalendarDays },
    { id: 'completed' as TabType, label: 'Concluídas', icon: CheckCircle },
    { id: 'cancelled' as TabType, label: 'Canceladas', icon: XCircle },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-slate-900">
            {isDoctor ? 'Agenda de Consultas' : 'Minhas Consultas'}
          </h1>
          <p className="text-slate-500 mt-1">
            {isDoctor 
              ? 'Gerencie suas consultas e agenda'
              : 'Visualize e gerencie suas consultas'
            }
          </p>
        </div>
        
        {!isDoctor && (
          <Link href="/doctors">
            <Button>
              <Plus className="w-4 h-4" />
              Nova Consulta
            </Button>
          </Link>
        )}
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b border-slate-200">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-3 font-medium text-sm transition-colors border-b-2 -mb-px ${
              activeTab === tab.id
                ? 'text-primary border-primary'
                : 'text-slate-500 border-transparent hover:text-slate-700'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Appointments List */}
      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3].map(i => (
            <Card key={i} className="p-6">
              <div className="flex items-center gap-4">
                <Skeleton variant="circular" width={56} height={56} />
                <div className="flex-1 space-y-2">
                  <Skeleton variant="text" width="50%" />
                  <Skeleton variant="text" width="30%" />
                </div>
                <Skeleton variant="rectangular" width={100} height={36} />
              </div>
            </Card>
          ))}
        </div>
      ) : appointments.length > 0 ? (
        <div className="space-y-4">
          {appointments.map((apt, index) => {
            const otherPerson = isDoctor ? apt.patient?.user : apt.doctor?.user;
            const isUpcoming = activeTab === 'upcoming';
            const canJoin = canJoinCall(apt);

            return (
              <Card 
                key={apt.id}
                className="animate-slide-up overflow-hidden"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <div className="flex flex-col md:flex-row md:items-center gap-4 p-6">
                  {/* Left: Doctor/Patient Info */}
                  <div className="flex items-center gap-4 flex-1">
                    <div className="relative">
                      <Avatar 
                        src={otherPerson?.avatar} 
                        name={otherPerson?.name || 'User'} 
                        size="lg"
                      />
                      <div className={`absolute -bottom-1 -right-1 w-6 h-6 rounded-full flex items-center justify-center ${
                        apt.status === 'SCHEDULED' ? 'bg-secondary' : apt.status === 'IN_PROGRESS' ? 'bg-warning' : 'bg-slate-300'
                      }`}>
                        {getTypeIcon(apt.type)}
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-slate-900 truncate">
                          {otherPerson?.name}
                        </h3>
                        {getStatusBadge(apt.status)}
                      </div>
                      <div className="flex items-center gap-3 mt-1 text-sm text-slate-500">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          {formatDate(apt.scheduledAt)}
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {formatTime(apt.scheduledAt)}
                        </div>
                        <span>•</span>
                        <span>{apt.duration}min</span>
                      </div>
                      {apt.patientNotes && isUpcoming && (
                        <p className="text-sm text-slate-400 mt-2 truncate">
                          "{apt.patientNotes}"
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Right: Actions */}
                  <div className="flex items-center gap-3">
                    {isUpcoming && canJoin && (
                      <Link href={`/consultations/${apt.id}`}>
                        <Button>
                          <Play className="w-4 h-4" />
                          Iniciar
                        </Button>
                      </Link>
                    )}
                    
                    {isUpcoming && apt.status === 'SCHEDULED' && (
                      <>
                        <Button variant="ghost" size="sm">
                          <Calendar className="w-4 h-4" />
                          Reagendar
                        </Button>
                        <Button 
                          variant="danger" 
                          size="sm"
                          onClick={() => setCancelModal(apt.id)}
                        >
                          <XCircle className="w-4 h-4" />
                        </Button>
                      </>
                    )}

                    {!isUpcoming && (
                      <Link href={`/consultations/${apt.id}`}>
                        <Button variant="outline" size="sm">
                          Ver Detalhes
                          <ArrowRight className="w-4 h-4" />
                        </Button>
                      </Link>
                    )}
                  </div>
                </div>

                {/* Join Call Banner */}
                {isUpcoming && canJoin && (
                  <div className="px-6 py-4 bg-primary/5 border-t border-primary/10 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                        <Video className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium text-slate-900">Sua consulta está prestes a começar!</p>
                        <p className="text-sm text-slate-500">Clique em "Iniciar" para entrar na videochamada</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="w-3 h-3 rounded-full bg-primary animate-pulse" />
                      <span className="text-sm font-medium text-primary">Pronto para começar</span>
                    </div>
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      ) : (
        <Card className="text-center py-12">
          <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Calendar className="w-8 h-8 text-slate-400" />
          </div>
          <h3 className="font-semibold text-slate-800 mb-2">
            Nenhuma consulta {activeTab === 'upcoming' ? 'agendada' : activeTab === 'completed' ? 'concluída' : 'cancelada'}
          </h3>
          <p className="text-slate-500 text-sm mb-4">
            {activeTab === 'upcoming' 
              ? 'Agende sua primeira consulta com um de nossos médicos'
              : 'Suas consultas aparecerão aqui'
            }
          </p>
          {activeTab === 'upcoming' && !isDoctor && (
            <Link href="/doctors">
              <Button>
                <Plus className="w-4 h-4" />
                Agendar Consulta
              </Button>
            </Link>
          )}
        </Card>
      )}

      {/* Cancel Modal */}
      <Modal 
        open={!!cancelModal} 
        onClose={() => setCancelModal(null)}
        title="Cancelar Consulta"
        description="Tem certeza que deseja cancelar esta consulta?"
        size="sm"
      >
        <div className="space-y-4">
          <div className="p-4 rounded-xl bg-warning/10 border border-warning/20">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-warning flex-shrink-0 mt-0.5" />
              <div className="text-sm text-slate-700">
                <p className="font-medium">Aviso importante</p>
                <p className="mt-1">
                  Cancelamentos com menos de 24h de antecedência podem estar sujeitos a políticas de reembolso.
                </p>
              </div>
            </div>
          </div>
        </div>
        <ModalFooter>
          <Button variant="secondary" onClick={() => setCancelModal(null)}>
            Manter Consulta
          </Button>
          <Button variant="danger" loading={cancelling} onClick={() => cancelModal && handleCancel(cancelModal)}>
            Confirmar Cancelamento
          </Button>
        </ModalFooter>
      </Modal>
    </div>
  );
}