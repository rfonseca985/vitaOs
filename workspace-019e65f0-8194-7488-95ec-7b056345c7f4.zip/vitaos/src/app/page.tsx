import Link from 'next/link';
import { 
  Video, Bot, FileText, Shield, Clock, Star, Heart, 
  Stethoscope, CheckCircle, ArrowRight, Play, Users,
  Calendar, Activity, Pill, Mic, MicOff, VideoOff
} from 'lucide-react';

export default function LandingPage() {
  return (
    <div className="min-h-screen">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-blue-700 flex items-center justify-center text-white font-bold text-lg">
                V
              </div>
              <span className="font-bold text-xl text-slate-800">vitaOS</span>
            </div>
            
            <div className="hidden md:flex items-center gap-6">
              <Link href="#features" className="text-slate-600 hover:text-slate-900 text-sm font-medium transition-colors">
                Funcionalidades
              </Link>
              <Link href="#how-it-works" className="text-slate-600 hover:text-slate-900 text-sm font-medium transition-colors">
                Como Funciona
              </Link>
              <Link href="#specialties" className="text-slate-600 hover:text-slate-900 text-sm font-medium transition-colors">
                Especialidades
              </Link>
              <Link href="#faq" className="text-slate-600 hover:text-slate-900 text-sm font-medium transition-colors">
                FAQ
              </Link>
            </div>

            <div className="flex items-center gap-3">
              <Link href="/login" className="text-slate-600 hover:text-slate-900 text-sm font-medium transition-colors">
                Entrar
              </Link>
              <Link href="/register" className="btn btn-primary text-sm">
                Cadastre-se
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="animate-fade-in">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
                <span className="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
                Telemedicina com IA
              </div>
              
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-slate-900 leading-tight mb-6">
                Saúde ao alcance de todos,{' '}
                <span className="text-primary">em qualquer lugar.</span>
              </h1>
              
              <p className="text-lg md:text-xl text-slate-600 mb-8 leading-relaxed">
                Consultas médicas online com profissionais qualificados. 
                Sem filas, sem deslocamento, com acompanhamento por IA.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 mb-12">
                <Link href="/register?role=patient" className="btn btn-primary text-lg px-8 py-3">
                  <Calendar className="w-5 h-5" />
                  Agendar Consulta
                </Link>
                <Link href="/register?role=doctor" className="btn btn-outline text-lg px-8 py-3">
                  Sou Médico
                </Link>
              </div>

              <div className="flex items-center gap-8">
                <div className="text-center">
                  <p className="text-3xl font-bold text-slate-900">50K+</p>
                  <p className="text-sm text-slate-500">Pacientes atendidos</p>
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold text-slate-900">2K+</p>
                  <p className="text-sm text-slate-500">Médicos disponíveis</p>
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold text-slate-900">4.9</p>
                  <div className="flex items-center justify-center gap-0.5">
                    {[1,2,3,4,5].map(i => (
                      <Star key={i} className="w-4 h-4 text-warning fill-warning" />
                    ))}
                  </div>
                  <p className="text-sm text-slate-500">Avaliação média</p>
                </div>
              </div>
            </div>

            <div className="relative animate-slide-up stagger-2">
              <div className="relative bg-gradient-to-br from-primary/5 to-accent/5 rounded-3xl p-8">
                {/* Video consultation mockup */}
                <div className="bg-slate-900 rounded-2xl overflow-hidden shadow-2xl">
                  <div className="aspect-video relative">
                    {/* Main video area */}
                    <div className="absolute inset-0 bg-gradient-to-br from-slate-700 to-slate-800 flex items-center justify-center">
                      <div className="text-center">
                        <div className="w-24 h-24 rounded-full bg-primary/20 flex items-center justify-center mb-4 mx-auto">
                          <Stethoscope className="w-12 h-12 text-primary" />
                        </div>
                        <p className="text-white/80">Dr. Carlos Silva</p>
                        <p className="text-white/50 text-sm">Cardiologista • CRM 12345</p>
                      </div>
                    </div>
                    
                    {/* Self view */}
                    <div className="absolute bottom-4 right-4 w-32 h-24 bg-slate-700 rounded-lg overflow-hidden border-2 border-slate-600 flex items-center justify-center">
                      <div className="w-8 h-8 rounded-full bg-primary/30 flex items-center justify-center">
                        <Users className="w-4 h-4 text-white/50" />
                      </div>
                    </div>

                    {/* Controls */}
                    <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-3">
                      <button className="w-12 h-12 rounded-full bg-slate-700/80 flex items-center justify-center text-white hover:bg-slate-600 transition-colors">
                        <Mic className="w-5 h-5" />
                      </button>
                      <button className="w-12 h-12 rounded-full bg-slate-700/80 flex items-center justify-center text-white hover:bg-slate-600 transition-colors">
                        <Video className="w-5 h-5" />
                      </button>
                      <button className="w-12 h-12 rounded-full bg-error flex items-center justify-center text-white hover:bg-red-600 transition-colors">
                        <MicOff className="w-5 h-5" />
                      </button>
                    </div>

                    {/* Timer */}
                    <div className="absolute top-4 left-4 px-3 py-1.5 rounded-full bg-slate-800/80 text-white text-sm flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-secondary animate-pulse"></span>
                      12:34
                    </div>

                    {/* Quality indicator */}
                    <div className="absolute top-4 right-4 px-3 py-1.5 rounded-full bg-slate-800/80 text-secondary text-sm flex items-center gap-1">
                      <div className="w-2 h-2 rounded-full bg-secondary"></div>
                      HD
                    </div>
                  </div>
                </div>

                {/* AI assistant floating card */}
                <div className="absolute -left-4 top-1/4 bg-white rounded-xl shadow-xl p-4 animate-slide-up stagger-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-accent/10 flex items-center justify-center">
                      <Bot className="w-5 h-5 text-accent" />
                    </div>
                    <div>
                      <p className="font-semibold text-slate-800 text-sm">vitasAI</p>
                      <p className="text-xs text-slate-500">Assistente de saúde</p>
                    </div>
                  </div>
                  <p className="text-sm text-slate-600 mt-2">
                    "Sua frequência cardíaca está normal. Continue monitoramento..."
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
              Funcionalidades pensadas para você
            </h2>
            <p className="text-lg text-slate-600 max-w-2xl mx-auto">
              Uma plataforma completa que coloca a tecnologia a serviço da sua saúde
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: Video,
                title: 'Video Consultas HD',
                description: 'Conecte-se com seu médico por video em alta qualidade. Interface simples e intuitiva, sem downloads.',
                color: 'primary',
              },
              {
                icon: Bot,
                title: 'IA Assistente vitasAI',
                description: 'Triagem inteligente de sintomas, acompanhamento personalizado e suporte 24 horas.',
                color: 'accent',
              },
              {
                icon: FileText,
                title: 'Prontuário Digital',
                description: 'Todo seu histórico médico acessível em um só lugar. Resultados de exames, receitas e diagnósticos.',
                color: 'secondary',
              },
              {
                icon: Clock,
                title: 'Agendamento Inteligente',
                description: 'Encontre horários disponíveis em segundos. Lembretes automáticos via email e SMS.',
                color: 'warning',
              },
              {
                icon: Shield,
                title: 'Dados Seguros',
                description: 'Criptografia de ponta, LGPD compliant. Suas informações médicas protegidas.',
                color: 'primary',
              },
              {
                icon: Pill,
                title: 'Receitas Digitais',
                description: 'Prescrições válidas emitidas durante a consulta. QR code para verificação de autenticidade.',
                color: 'secondary',
              },
            ].map((feature, index) => (
              <div 
                key={feature.title}
                className="card card-hover p-6 animate-slide-up"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <div className={`w-12 h-12 rounded-xl bg-${feature.color}/10 flex items-center justify-center mb-4`}>
                  <feature.icon className={`w-6 h-6 text-${feature.color}`} />
                </div>
                <h3 className="text-lg font-semibold text-slate-900 mb-2">{feature.title}</h3>
                <p className="text-slate-600 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section id="how-it-works" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
              Como funciona
            </h2>
            <p className="text-lg text-slate-600">
              Em apenas 3 passos você tem acesso à saúde de qualidade
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                step: 1,
                title: 'Cadastre-se',
                description: 'Crie sua conta em minutos. Preencha seu perfil de saúde para um atendimento personalizado.',
                icon: Users,
              },
              {
                step: 2,
                title: 'Escolha seu médico',
                description: 'Busque por especialidade, leia avaliações e escolha o profissional ideal para você.',
                icon: Stethoscope,
              },
              {
                step: 3,
                title: 'Consulte online',
                description: 'Acesse a sala de espera virtual, inicie sua videochamada e receba seu atendimento.',
                icon: Video,
              },
            ].map((item, index) => (
              <div key={item.step} className="text-center relative">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
                  <item.icon className="w-8 h-8 text-primary" />
                </div>
                <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-primary text-white font-bold flex items-center justify-center">
                  {item.step}
                </div>
                <h3 className="text-xl font-semibold text-slate-900 mb-3">{item.title}</h3>
                <p className="text-slate-600 leading-relaxed">{item.description}</p>
                {index < 2 && (
                  <div className="hidden md:block absolute top-8 -right-4 text-slate-300">
                    <ArrowRight className="w-8 h-8" />
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link href="/register" className="btn btn-primary text-lg px-8 py-3">
              Comece Agora
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* Specialties */}
      <section id="specialties" className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
              Especialistas disponíveis
            </h2>
            <p className="text-lg text-slate-600">
              Mais de 30 especialidades médicas para cuidar de você
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {[
              'Clínico Geral', 'Cardiologia', 'Dermatologia', 'Endocrinologia',
              'Gastroenterologia', 'Neurologia', 'Ortopedia', 'Oftalmologia',
              'Pediatria', 'Psiquiatria', 'Ginecologia', 'Urologia',
              'Pneumologia', 'Reumatologia', 'Oncologia', 'Nutrição',
              'Psicologia', 'Fisioterapia', 'Geriatria', 'Medicina do Trabalho',
            ].map((specialty, index) => (
              <div 
                key={specialty}
                className="card card-hover p-4 text-center cursor-pointer animate-fade-in"
                style={{ animationDelay: `${index * 30}ms` }}
              >
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-2">
                  <Activity className="w-5 h-5 text-primary" />
                </div>
                <p className="text-sm font-medium text-slate-800">{specialty}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="gradient-primary rounded-3xl p-12 text-center text-white relative overflow-hidden">
            <div className="absolute inset-0 opacity-10">
              <div className="absolute top-0 left-0 w-40 h-40 bg-white rounded-full -translate-x-1/2 -translate-y-1/2"></div>
              <div className="absolute bottom-0 right-0 w-60 h-60 bg-white rounded-full translate-x-1/3 translate-y-1/3"></div>
            </div>
            
            <div className="relative z-10">
              <Heart className="w-16 h-16 mx-auto mb-6 animate-pulse" />
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Sua saúde merece o melhor cuidado
              </h2>
              <p className="text-xl text-white/80 mb-8 max-w-2xl mx-auto">
                Junte-se a milhares de pessoas que já transformaram sua experiência com saúde digital
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link href="/register" className="btn bg-white text-primary hover:bg-slate-100 text-lg px-8 py-3">
                  <CheckCircle className="w-5 h-5" />
                  Criar Conta Grátis
                </Link>
                <Link href="#features" className="btn bg-white/20 text-white hover:bg-white/30 text-lg px-8 py-3">
                  Saiba Mais
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-50">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
              Perguntas Frequentes
            </h2>
          </div>

          <div className="space-y-4">
            {[
              {
                q: 'A consulta online é válida legalmente?',
                a: 'Sim! As teleconsultas são regulamentadas pelo CFM e têm validade legal. Nossa plataforma segue todos os padrões de segurança e privacidade exigidos.',
              },
              {
                q: 'Como funciona o pagamento?',
                a: 'Aceitamos cartão de crédito, PIX e transferência bancária. O pagamento é feito de forma segura diretamente na plataforma antes da consulta.',
              },
              {
                q: 'Posso pedir reembolso?',
                a: 'Sim! Se você cancelar a consulta com pelo menos 24h de antecedência, o reembolso é integral. Para cancelamentos em menor tempo, aplicamos política de reembolso parcial.',
              },
              {
                q: 'A vitasAI substitui o médico?',
                a: 'Não! A vitasAI é uma assistente de saúde que auxilia na triagem e acompanhamento. Ela não substitui o julgamento médico profissional, sendo sempre recomendada a consulta com um médico.',
              },
              {
                q: 'Meus dados estão seguros?',
                a: 'Absolutamente! Utilizamos criptografia de ponta, somos LGPD compliant e seguimos rigorosos protocolos de segurança. Seus dados médicos são protegidos por lei.',
              },
            ].map((faq, index) => (
              <details 
                key={index}
                className="card group"
              >
                <summary className="p-6 cursor-pointer font-semibold text-slate-800 flex items-center justify-between">
                  {faq.q}
                  <ArrowRight className="w-5 h-5 text-slate-400 group-open:rotate-90 transition-transform" />
                </summary>
                <div className="px-6 pb-6 text-slate-600 leading-relaxed">
                  {faq.a}
                </div>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 sm:px-6 lg:px-8 border-t border-slate-200">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-blue-700 flex items-center justify-center text-white font-bold text-lg">
                  V
                </div>
                <span className="font-bold text-xl text-slate-800">vitaOS</span>
              </div>
              <p className="text-slate-600 text-sm leading-relaxed">
                Plataforma de telemedicina inteligente, conectando pacientes a médicos qualificados com segurança e tecnologia.
              </p>
            </div>

            <div>
              <h4 className="font-semibold text-slate-800 mb-4">Produto</h4>
              <ul className="space-y-2 text-sm text-slate-600">
                <li><Link href="#features" className="hover:text-primary transition-colors">Funcionalidades</Link></li>
                <li><Link href="#specialties" className="hover:text-primary transition-colors">Especialidades</Link></li>
                <li><Link href="#how-it-works" className="hover:text-primary transition-colors">Como Funciona</Link></li>
                <li><Link href="/pricing" className="hover:text-primary transition-colors">Preços</Link></li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold text-slate-800 mb-4">Suporte</h4>
              <ul className="space-y-2 text-sm text-slate-600">
                <li><Link href="/help" className="hover:text-primary transition-colors">Central de Ajuda</Link></li>
                <li><Link href="/contact" className="hover:text-primary transition-colors">Contato</Link></li>
                <li><Link href="/faq" className="hover:text-primary transition-colors">FAQ</Link></li>
                <li><Link href="/status" className="hover:text-primary transition-colors">Status do Sistema</Link></li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold text-slate-800 mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-slate-600">
                <li><Link href="/privacy" className="hover:text-primary transition-colors">Política de Privacidade</Link></li>
                <li><Link href="/terms" className="hover:text-primary transition-colors">Termos de Uso</Link></li>
                <li><Link href="/lgpd" className="hover:text-primary transition-colors">LGPD</Link></li>
                <li><Link href="/cookies" className="hover:text-primary transition-colors">Cookies</Link></li>
              </ul>
            </div>
          </div>

          <div className="pt-8 border-t border-slate-200 flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-sm text-slate-500">
              © 2024 vitaOS. Todos os direitos reservados.
            </p>
            <div className="flex items-center gap-6">
              <a href="#" className="text-slate-400 hover:text-slate-600 transition-colors">
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z"/></svg>
              </a>
              <a href="#" className="text-slate-400 hover:text-slate-600 transition-colors">
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>
              </a>
              <a href="#" className="text-slate-400 hover:text-slate-600 transition-colors">
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}