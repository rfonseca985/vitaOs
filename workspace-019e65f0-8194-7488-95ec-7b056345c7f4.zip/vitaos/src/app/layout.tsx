import type { Metadata } from 'next';
import './globals.css';
import { Toaster } from 'react-hot-toast';
import { AuthProvider } from '@/components/AuthProvider';

export const metadata: Metadata = {
  title: {
    default: 'vitaOS - Telemedicina Inteligente',
    template: '%s | vitaOS',
  },
  description: 'Plataforma de telemedicina com IA integrada. Consultas médicas online com médicos qualificados. Sem filas, sem deslocamento.',
  keywords: ['telemedicina', 'consulta online', 'médico online', 'saúde digital', 'atendimento médico', 'vitaOS'],
  authors: [{ name: 'vitaOS' }],
  creator: 'vitaOS',
  publisher: 'vitaOS',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL(process.env.NEXTAUTH_URL || 'http://localhost:3000'),
  openGraph: {
    type: 'website',
    locale: 'pt_BR',
    url: '/',
    siteName: 'vitaOS',
    title: 'vitaOS - Telemedicina Inteligente',
    description: 'Consultas médicas online com IA integrada',
    images: [
      {
        url: '/og-image.png',
        width: 1200,
        height: 630,
        alt: 'vitaOS - Telemedicina Inteligente',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'vitaOS - Telemedicina Inteligente',
    description: 'Consultas médicas online com IA integrada',
    images: ['/og-image.png'],
  },
  robots: {
    index: true,
    follow: true,
  },
  icons: {
    icon: [
      { url: '/favicon.ico' },
      { url: '/favicon-16x16.png', sizes: '16x16', type: 'image/png' },
      { url: '/favicon-32x32.png', sizes: '32x32', type: 'image/png' },
    ],
    apple: '/apple-touch-icon.png',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pt-BR">
      <body className="min-h-screen bg-background antialiased">
        <AuthProvider>
          {children}
          <Toaster 
            position="top-right"
            toastOptions={{
              duration: 4000,
              style: {
                background: '#fff',
                color: '#0F172A',
                borderRadius: '12px',
                boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
              },
              success: {
                iconTheme: {
                  primary: '#10B981',
                  secondary: '#fff',
                },
              },
              error: {
                iconTheme: {
                  primary: '#EF4444',
                  secondary: '#fff',
                },
              },
            }}
          />
        </AuthProvider>
      </body>
    </html>
  );
}