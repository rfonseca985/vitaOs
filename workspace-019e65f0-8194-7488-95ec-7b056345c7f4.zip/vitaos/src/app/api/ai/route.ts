import { NextRequest, NextResponse } from 'next/server';
import { getUserFromSession } from '@/lib/auth';
import { chatWithAI, analyzeSymptoms } from '@/lib/ai';

export async function POST(req: NextRequest) {
  try {
    const session = await getUserFromSession();
    if (!session) {
      return NextResponse.json({ error: 'Não autenticado' }, { status: 401 });
    }

    const data = await req.json();
    const { messages, type } = data;

    if (!messages || !Array.isArray(messages)) {
      return NextResponse.json(
        { error: 'Mensagens são obrigatórias' },
        { status: 400 }
      );
    }

    let response: string;

    if (type === 'symptoms') {
      // Symptom analysis mode
      const symptoms = data.symptoms || [];
      const additionalInfo = data.additionalInfo || {};
      
      const analysis = await analyzeSymptoms(symptoms, additionalInfo, session.id);
      response = JSON.stringify(analysis);
    } else {
      // Regular chat mode
      response = await chatWithAI(messages, session.id, session.role as 'PATIENT' | 'DOCTOR');
    }

    return NextResponse.json({ response });
  } catch (error) {
    console.error('AI chat error:', error);
    return NextResponse.json(
      { error: 'Erro ao processar mensagem. Tente novamente.' },
      { status: 500 }
    );
  }
}