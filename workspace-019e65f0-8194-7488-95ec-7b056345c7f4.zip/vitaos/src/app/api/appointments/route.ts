import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getUserFromSession } from '@/lib/auth';
import { generateId } from '@/lib/utils';

export async function GET(req: NextRequest) {
  try {
    const session = await getUserFromSession();
    if (!session) {
      return NextResponse.json({ error: 'Não autenticado' }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const status = searchParams.get('status');
    const upcoming = searchParams.get('upcoming') === 'true';
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');

    // Build where clause based on user role
    const isDoctor = session.role === 'DOCTOR';
    const where: any = isDoctor 
      ? { doctorId: session.id } 
      : { patientId: session.id };

    if (status) {
      where.status = status;
    }

    if (upcoming) {
      where.scheduledAt = { gte: new Date() };
      where.status = 'SCHEDULED';
    }

    // Get appointments
    const appointments = await prisma.appointment.findMany({
      where,
      include: {
        patient: {
          include: {
            user: {
              select: { id: true, name: true, email: true, avatar: true },
            },
          },
        },
        doctor: {
          include: {
            user: {
              select: { id: true, name: true, email: true, avatar: true },
            },
          },
        },
      },
      orderBy: { scheduledAt: 'asc' },
      skip: (page - 1) * limit,
      take: limit,
    });

    const total = await prisma.appointment.count({ where });

    return NextResponse.json({
      appointments,
      total,
      page,
      limit,
    });
  } catch (error) {
    console.error('Get appointments error:', error);
    return NextResponse.json(
      { error: 'Erro ao buscar consultas' },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getUserFromSession();
    if (!session) {
      return NextResponse.json({ error: 'Não autenticado' }, { status: 401 });
    }

    const data = await req.json();
    const { doctorId, scheduledAt, duration, type, patientNotes } = data;

    // Validation
    if (!doctorId || !scheduledAt) {
      return NextResponse.json(
        { error: 'Médico e data/hora são obrigatórios' },
        { status: 400 }
      );
    }

    // Check if doctor exists
    const doctor = await prisma.doctor.findUnique({
      where: { userId: doctorId },
      include: { user: true },
    });

    if (!doctor) {
      return NextResponse.json(
        { error: 'Médico não encontrado' },
        { status: 404 }
      );
    }

    // Check for conflicting appointments
    const scheduledDate = new Date(scheduledAt);
    const endTime = new Date(scheduledDate.getTime() + (duration || 30) * 60000);

    const conflictingAppointment = await prisma.appointment.findFirst({
      where: {
        doctorId,
        status: { in: ['SCHEDULED', 'IN_PROGRESS'] },
        OR: [
          {
            scheduledAt: { lte: scheduledDate },
            AND: {
              scheduledAt: { gte: new Date(scheduledDate.getTime() - (duration || 30) * 60000) },
            },
          },
          {
            scheduledAt: { gte: scheduledDate, lt: endTime },
          },
        ],
      },
    });

    if (conflictingAppointment) {
      return NextResponse.json(
        { error: 'Horário não disponível. Por favor, escolha outro horário.' },
        { status: 409 }
      );
    }

    // Create appointment
    const appointment = await prisma.appointment.create({
      data: {
        patientId: session.id,
        doctorId,
        scheduledAt: scheduledDate,
        duration: duration || 30,
        type: type || 'VIDEO',
        patientNotes,
        // Generate room URL for video calls
        roomUrl: type === 'VIDEO' ? `/room/${generateId()}` : null,
      },
      include: {
        patient: {
          include: {
            user: {
              select: { id: true, name: true, email: true, avatar: true },
            },
          },
        },
        doctor: {
          include: {
            user: {
              select: { id: true, name: true, email: true, avatar: true },
            },
          },
        },
      },
    });

    // Update doctor consultation count
    await prisma.doctor.update({
      where: { userId: doctorId },
      data: { totalConsultations: { increment: 1 } },
    });

    // Update patient consultation count
    await prisma.patient.update({
      where: { userId: session.id },
      data: { totalConsultations: { increment: 1 } },
    });

    return NextResponse.json({ appointment });
  } catch (error) {
    console.error('Create appointment error:', error);
    return NextResponse.json(
      { error: 'Erro ao criar consulta' },
      { status: 500 }
    );
  }
}