import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { hashPassword, createSession } from '@/lib/auth';
import { cookies } from 'next/headers';
import { validateCPF, validateCRM } from '@/lib/utils';

export async function POST(req: NextRequest) {
  try {
    const data = await req.json();
    const { 
      email, password, name, phone, dateOfBirth, cpf, 
      role, crm, crmState, specialty 
    } = data;

    // Validation
    if (!email || !password || !name || !role) {
      return NextResponse.json(
        { error: 'Campos obrigatórios faltando' },
        { status: 400 }
      );
    }

    // Password minimum length
    if (password.length < 6) {
      return NextResponse.json(
        { error: 'Senha deve ter pelo menos 6 caracteres' },
        { status: 400 }
      );
    }

    // Check if email already exists
    const existingUser = await prisma.user.findUnique({
      where: { email },
    });

    if (existingUser) {
      return NextResponse.json(
        { error: 'Email já cadastrado' },
        { status: 400 }
      );
    }

    // Validate CPF for patients
    if (role === 'PATIENT' && cpf && !validateCPF(cpf)) {
      return NextResponse.json(
        { error: 'CPF inválido' },
        { status: 400 }
      );
    }

    // Validate CRM for doctors
    if (role === 'DOCTOR' && crm && !validateCRM(crm)) {
      return NextResponse.json(
        { error: 'CRM inválido' },
        { status: 400 }
      );
    }

    // Check if CRM already exists
    if (role === 'DOCTOR' && crm) {
      const existingCRM = await prisma.doctor.findUnique({
        where: { crm },
      });

      if (existingCRM) {
        return NextResponse.json(
          { error: 'CRM já cadastrado' },
          { status: 400 }
        );
      }
    }

    // Hash password
    const hashedPassword = await hashPassword(password);

    // Create user with transaction
    const result = await prisma.$transaction(async (tx) => {
      // Create user
      const user = await tx.user.create({
        data: {
          email,
          password: hashedPassword,
          name,
          phone: phone || null,
          dateOfBirth: dateOfBirth ? new Date(dateOfBirth) : null,
          cpf: cpf || null,
          role,
          isVerified: role === 'PATIENT', // Patients are verified by default
        },
      });

      // Create doctor or patient profile
      if (role === 'DOCTOR') {
        await tx.doctor.create({
          data: {
            userId: user.id,
            crm: crm || '',
            crmState: crmState || 'SP',
            specialty: specialty || 'Clínico Geral',
            consultationPrice: 0,
            consultationDuration: 30,
          },
        });
      } else if (role === 'PATIENT') {
        await tx.patient.create({
          data: {
            userId: user.id,
          },
        });
      }

      return user;
    });

    // Fetch complete user data
    const completeUser = await prisma.user.findUnique({
      where: { id: result.id },
      include: {
        doctor: true,
        patient: true,
      },
    });

    // Create session
    const sessionToken = await createSession(result.id);
    const cookieStore = await cookies();
    cookieStore.set('vitaos_session', sessionToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 60 * 60 * 24 * 7, // 7 days
      path: '/',
    });

    // Return user data (exclude password)
    const { password: _, ...userWithoutPassword } = completeUser!;

    return NextResponse.json({
      user: userWithoutPassword,
      doctor: completeUser?.doctor,
      patient: completeUser?.patient,
    });
  } catch (error) {
    console.error('Register error:', error);
    return NextResponse.json(
      { error: 'Erro ao criar conta. Tente novamente.' },
      { status: 500 }
    );
  }
}