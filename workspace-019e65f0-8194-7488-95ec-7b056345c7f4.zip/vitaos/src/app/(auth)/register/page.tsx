'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { useAuth } from '@/components/AuthProvider';
import { Input } from '@/components/ui/Input';
import { Select } from '@/components/ui/Select';
import { Button } from '@/components/ui/Button';
import { Card, CardHeader, CardTitle, CardDescription } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { BRAZILIAN_STATES, COMMON_CONDITIONS, COMMON_ALLERGIES, BLOOD_TYPES } from '@/lib/utils';
import { User, Stethoscope, CheckCircle, ArrowRight, ArrowLeft } from 'lucide-react';

const SPECIALTIES = [
  'Clínica Geral', 'Cardiologia', 'Dermatologia', 'Endocrinologia',
  'Gastroenterologia', 'Neurologia', 'Ortopedia', 'Oftalmologia',
  'Pediatria', 'Psiquiatria', 'Ginecologia', 'Urologia',
  'Pneumologia', 'Reumatologia', 'Oncologia', 'Nutrição',
  'Psicologia', 'Fisioterapia', 'Geriatria',
];

export default function RegisterPage() {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { register, user, isLoading, isAuthenticated } = useAuth();
  const router = useRouter();
  const searchParams = useSearchParams();
  
  // Form data
  const [formData, setFormData] = useState({
    // Common fields
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    phone: '',
    dateOfBirth: '',
    cpf: '',
    role: 'PATIENT' as 'PATIENT' | 'DOCTOR',
    // Doctor specific
    crm: '',
    crmState: 'SP',
    specialty: '',
  });

  useEffect(() => {
    const role = searchParams.get('role');
    if (role === 'doctor') {
      setFormData(prev => ({ ...prev, role: 'DOCTOR' }));
    }
  }, [searchParams]);

  useEffect(() => {
    if (!isLoading && isAuthenticated) {
      router.push('/dashboard');
    }
  }, [isLoading, isAuthenticated, router]);

  const updateFormData = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    setError('');
  };

  const validateStep1 = () => {
    if (!formData.name.trim()) {
      setError('Nome é obrigatório');
      return false;
    }
    if (!formData.email.includes('@')) {
      setError('Email inválido');
      return false;
    }
    if (formData.password.length < 6) {
      setError('Senha deve ter pelo menos 6 caracteres');
      return false;
    }
    if (formData.password !== formData.confirmPassword) {
      setError('As senhas não coincidem');
      return false;
    }
    return true;
  };

  const validateStep2 = () => {
    if (!formData.phone.trim()) {
      setError('Telefone é obrigatório');
      return false;
    }
    if (!formData.dateOfBirth) {
      setError('Data de nascimento é obrigatória');
      return false;
    }
    if (formData.role === 'PATIENT' && !formData.cpf.trim()) {
      setError('CPF é obrigatório');
      return false;
    }
    if (formData.role === 'DOCTOR' && !formData.crm.trim()) {
      setError('CRM é obrigatório');
      return false;
    }
    if (formData.role === 'DOCTOR' && !formData.specialty) {
      setError('Especialidade é obrigatória');
      return false;
    }
    return true;
  };

  const handleNextStep = () => {
    setError('');
    if (step === 1 && validateStep1()) {
      setStep(2);
    }
  };

  const handleSubmit = async () => {
    if (!validateStep2()) return;

    setLoading(true);
    const result = await register(formData);

    if (result.success) {
      router.push('/dashboard');
    } else {
      setError(result.error || 'Erro ao criar conta');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-white to-accent/5 flex items-center justify-center p-4 py-8">
      <div className="w-full max-w-lg animate-fade-in">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-3">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary to-blue-700 flex items-center justify-center text-white font-bold text-2xl shadow-lg">
              V
            </div>
            <div className="text-left">
              <h1 className="font-bold text-slate-800 text-2xl">vitaOS</h1>
              <p className="text-xs text-slate-500">Telemedicina Inteligente</p>
            </div>
          </Link>
        </div>

        {/* Progress Steps */}
        <div className="flex items-center justify-center gap-2 mb-8">
          {[1, 2].map((s) => (
            <div key={s} className="flex items-center gap-2">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-colors ${
                step >= s ? 'bg-primary text-white' : 'bg-slate-200 text-slate-500'
              }`}>
                {step > s ? <CheckCircle size={16} /> : s}
              </div>
              {s < 2 && (
                <div className={`w-12 h-0.5 ${step > s ? 'bg-primary' : 'bg-slate-200'}`} />
              )}
            </div>
          ))}
        </div>

        {/* Form Card */}
        <Card className="shadow-xl">
          <CardHeader>
            <div className="flex items-center justify-center gap-2 mb-2">
              {formData.role === 'PATIENT' ? (
                <User className="w-6 h-6 text-primary" />
              ) : (
                <Stethoscope className="w-6 h-6 text-primary" />
              )}
            </div>
            <CardTitle className="text-2xl text-center">
              {step === 1 ? 'Criar sua conta' : 'Informações adicionais'}
            </CardTitle>
            <CardDescription className="text-center">
              {formData.role === 'PATIENT' 
                ? 'Cadastre-se como paciente para agendar consultas'
                : 'Cadastre-se como médico para atender pacientes'
              }
            </CardDescription>
          </CardHeader>

          {/* Role Selector */}
          {step === 1 && (
            <div className="px-6 mb-4">
              <div className="grid grid-cols-2 gap-4">
                <button
                  onClick={() => updateFormData('role', 'PATIENT')}
                  className={`p-4 rounded-xl border-2 transition-all text-center ${
                    formData.role === 'PATIENT'
                      ? 'border-primary bg-primary/5'
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <User className={`w-8 h-8 mx-auto mb-2 ${formData.role === 'PATIENT' ? 'text-primary' : 'text-slate-400'}`} />
                  <p className={`font-medium ${formData.role === 'PATIENT' ? 'text-primary' : 'text-slate-700'}`}>
                    Paciente
                  </p>
                  <p className="text-xs text-slate-500 mt-1">Agendar consultas</p>
                </button>

                <button
                  onClick={() => updateFormData('role', 'DOCTOR')}
                  className={`p-4 rounded-xl border-2 transition-all text-center ${
                    formData.role === 'DOCTOR'
                      ? 'border-primary bg-primary/5'
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <Stethoscope className={`w-8 h-8 mx-auto mb-2 ${formData.role === 'DOCTOR' ? 'text-primary' : 'text-slate-400'}`} />
                  <p className={`font-medium ${formData.role === 'DOCTOR' ? 'text-primary' : 'text-slate-700'}`}>
                    Médico
                  </p>
                  <p className="text-xs text-slate-500 mt-1">Atender pacientes</p>
                </button>
              </div>
            </div>
          )}

          <div className="space-y-4 px-6">
            {step === 1 && (
              <>
                <Input
                  label="Nome completo"
                  placeholder="Seu nome completo"
                  value={formData.name}
                  onChange={(e) => updateFormData('name', e.target.value)}
                />

                <Input
                  label="Email"
                  type="email"
                  placeholder="seu@email.com"
                  value={formData.email}
                  onChange={(e) => updateFormData('email', e.target.value)}
                />

                <Input
                  label="Senha"
                  type="password"
                  placeholder="Mínimo 6 caracteres"
                  value={formData.password}
                  onChange={(e) => updateFormData('password', e.target.value)}
                  helper="Use letras, números e símbolos"
                />

                <Input
                  label="Confirmar senha"
                  type="password"
                  placeholder="Repita sua senha"
                  value={formData.confirmPassword}
                  onChange={(e) => updateFormData('confirmPassword', e.target.value)}
                />
              </>
            )}

            {step === 2 && (
              <>
                <Input
                  label="Telefone"
                  type="tel"
                  placeholder="(11) 99999-9999"
                  value={formData.phone}
                  onChange={(e) => updateFormData('phone', e.target.value)}
                />

                <Input
                  label="Data de nascimento"
                  type="date"
                  value={formData.dateOfBirth}
                  onChange={(e) => updateFormData('dateOfBirth', e.target.value)}
                />

                {formData.role === 'PATIENT' && (
                  <Input
                    label="CPF"
                    placeholder="000.000.000-00"
                    value={formData.cpf}
                    onChange={(e) => updateFormData('cpf', e.target.value)}
                    helper="Necessário para consultas médicas"
                  />
                )}

                {formData.role === 'DOCTOR' && (
                  <>
                    <div className="grid grid-cols-2 gap-4">
                      <Input
                        label="CRM"
                        placeholder="123456"
                        value={formData.crm}
                        onChange={(e) => updateFormData('crm', e.target.value)}
                      />

                      <Select
                        label="UF"
                        value={formData.crmState}
                        onChange={(e) => updateFormData('crmState', e.target.value)}
                        options={BRAZILIAN_STATES.map(s => ({ value: s, label: s }))}
                      />
                    </div>

                    <Select
                      label="Especialidade"
                      value={formData.specialty}
                      onChange={(e) => updateFormData('specialty', e.target.value)}
                      options={SPECIALTIES.map(s => ({ value: s, label: s }))}
                      placeholder="Selecione sua especialidade"
                    />

                    <div className="p-4 rounded-xl bg-accent/10 border border-accent/20">
                      <p className="text-sm text-accent font-medium mb-2">
                        ⚠️ Verificação necessária
                      </p>
                      <p className="text-xs text-slate-600">
                        Após o cadastro, você precisará enviar comprovante do CRM para verificação da sua conta.
                      </p>
                    </div>
                  </>
                )}
              </>
            )}

            {error && (
              <div className="p-3 rounded-lg bg-error/10 border border-error/20 text-error text-sm">
                {error}
              </div>
            )}
          </div>

          {/* Navigation Buttons */}
          <div className="px-6 pt-6 pb-2 flex gap-3">
            {step === 2 && (
              <Button
                variant="secondary"
                onClick={() => setStep(1)}
                className="flex-1"
              >
                <ArrowLeft size={18} />
                Voltar
              </Button>
            )}
            <Button
              onClick={step === 1 ? handleNextStep : handleSubmit}
              loading={loading}
              className="flex-1"
            >
              {step === 1 ? (
                <>
                  Continuar
                  <ArrowRight size={18} />
                </>
              ) : (
                <>
                  <CheckCircle size={18} />
                  Criar Conta
                </>
              )}
            </Button>
          </div>

          <div className="px-6 pb-6 text-center">
            <p className="text-sm text-slate-500">
              Já tem conta?{' '}
              <Link href="/login" className="text-primary hover:underline font-medium">
                Entrar
              </Link>
            </p>
          </div>
        </Card>
      </div>
    </div>
  );
}