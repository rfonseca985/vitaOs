'use client';

import { useState, useEffect, useRef } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { useAuth } from '@/components/AuthProvider';
import { Avatar } from '@/components/ui/Avatar';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { Card } from '@/components/ui/Card';
import toast from 'react-hot-toast';
import { 
  Mic, MicOff, Video, VideoOff, Phone, Monitor, 
  MessageSquare, MoreVertical, Users, Clock, Settings,
  Send, X, Maximize, Minimize, Shield, AlertCircle,
  Star, FileText, Pill, Activity
} from 'lucide-react';

export default function VideoRoomPage() {
  const params = useParams();
  const router = useRouter();
  const { user, isAuthenticated, isLoading } = useAuth();
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [showInfo, setShowInfo] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [callDuration, setCallDuration] = useState(0);
  const [chatMessages, setChatMessages] = useState<Array<{ id: string; sender: string; text: string; time: string }>>([]);
  const [chatInput, setChatInput] = useState('');
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const roomId = params.id;

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.push('/login');
    }
  }, [isLoading, isAuthenticated, router]);

  // Timer
  useEffect(() => {
    const timer = setInterval(() => {
      setCallDuration(prev => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Setup local video
  useEffect(() => {
    const setupVideo = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: true,
        });
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = stream;
        }
      } catch (error) {
        console.error('Failed to access media devices:', error);
        toast.error('Não foi possível acessar a câmera/microfone');
      }
    };
    setupVideo();
  }, []);

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleEndCall = () => {
    if (confirm('Tem certeza que deseja encerrar a consulta?')) {
      toast.success('Consulta encerrada');
      router.push('/appointments');
    }
  };

  const handleSendMessage = () => {
    if (!chatInput.trim()) return;
    setChatMessages(prev => [
      ...prev,
      {
        id: Date.now().toString(),
        sender: user?.name || 'Você',
        text: chatInput,
        time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
    setChatInput('');
  };

  // Demo patient data
  const patientData = {
    name: 'Maria Silva',
    conditions: ['Hipertensão', 'Diabetes Tipo 2'],
    allergies: ['Penicilina'],
    medications: ['Metformina 500mg', 'Losartan 50mg'],
  };

  return (
    <div className="h-screen bg-slate-900 flex flex-col">
      {/* Top Bar */}
      <div className="bg-slate-800 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/appointments" className="text-white/70 hover:text-white transition-colors">
            <X className="w-6 h-6" />
          </Link>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-secondary animate-pulse" />
            <span className="text-white font-medium">Em consulta</span>
          </div>
          <Badge variant="success" className="bg-secondary/20 text-secondary">
            <Clock className="w-3 h-3 mr-1" />
            {formatDuration(callDuration)}
          </Badge>
        </div>

        <div className="flex items-center gap-2">
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-white hover:bg-white/10"
            onClick={() => setShowInfo(!showInfo)}
          >
            <FileText className="w-5 h-5" />
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-white hover:bg-white/10"
            onClick={() => setIsFullscreen(!isFullscreen)}
          >
            {isFullscreen ? <Minimize className="w-5 h-5" /> : <Maximize className="w-5 h-5" />}
          </Button>
        </div>
      </div>

      <div className="flex-1 flex">
        {/* Main Video Area */}
        <div className={`flex-1 relative ${showChat ? 'mr-80' : ''}`}>
          {/* Remote Video (Placeholder) */}
          <div className="absolute inset-0 bg-gradient-to-br from-slate-800 to-slate-900 flex items-center justify-center">
            <div className="text-center">
              <div className="w-32 h-32 rounded-full bg-slate-700 flex items-center justify-center mx-auto mb-4">
                <Users className="w-16 h-16 text-slate-500" />
              </div>
              <p className="text-white/50">Aguardando conexão...</p>
              <p className="text-white/30 text-sm mt-2">
                Para testar, ative sua câmera e microfone abaixo
              </p>
            </div>
          </div>

          {/* Local Video (PiP) */}
          <div className="absolute bottom-4 right-4 w-48 md:w-64 aspect-video bg-slate-800 rounded-xl overflow-hidden shadow-2xl border-2 border-slate-700">
            <video
              ref={localVideoRef}
              autoPlay
              muted
              playsInline
              className={`w-full h-full object-cover ${isVideoOff ? 'hidden' : ''}`}
            />
            {isVideoOff && (
              <div className="w-full h-full flex items-center justify-center">
                <Avatar name={user?.name || 'User'} size="xl" />
              </div>
            )}
            <div className="absolute bottom-2 left-2 px-2 py-1 rounded bg-black/50 text-white text-xs">
              Você
            </div>
          </div>

          {/* Call Controls */}
          <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex items-center gap-3 bg-slate-800/90 backdrop-blur-sm rounded-full px-6 py-4">
            <button
              onClick={() => setIsMuted(!isMuted)}
              className={`w-14 h-14 rounded-full flex items-center justify-center transition-colors ${
                isMuted ? 'bg-error hover:bg-red-600' : 'bg-slate-700 hover:bg-slate-600'
              } text-white`}
            >
              {isMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
            </button>

            <button
              onClick={() => setIsVideoOff(!isVideoOff)}
              className={`w-14 h-14 rounded-full flex items-center justify-center transition-colors ${
                isVideoOff ? 'bg-error hover:bg-red-600' : 'bg-slate-700 hover:bg-slate-600'
              } text-white`}
            >
              {isVideoOff ? <VideoOff className="w-6 h-6" /> : <Video className="w-6 h-6" />}
            </button>

            <button className="w-14 h-14 rounded-full bg-slate-700 hover:bg-slate-600 flex items-center justify-center text-white transition-colors">
              <Monitor className="w-6 h-6" />
            </button>

            <button
              onClick={() => setShowChat(!showChat)}
              className={`w-14 h-14 rounded-full flex items-center justify-center transition-colors ${
                showChat ? 'bg-primary hover:bg-primary-dark' : 'bg-slate-700 hover:bg-slate-600'
              } text-white`}
            >
              <MessageSquare className="w-6 h-6" />
            </button>

            <button
              onClick={handleEndCall}
              className="w-14 h-14 rounded-full bg-error hover:bg-red-600 flex items-center justify-center text-white transition-colors"
            >
              <Phone className="w-6 h-6 rotate-135" />
            </button>
          </div>

          {/* Connection Quality */}
          <div className="absolute top-4 left-4 flex items-center gap-2 bg-black/50 rounded-full px-3 py-1.5">
            <div className="flex gap-0.5">
              {[1, 2, 3, 4].map(i => (
                <div 
                  key={i}
                  className={`w-1 rounded-full ${
                    i <= 3 ? 'bg-secondary' : 'bg-slate-600'
                  }`}
                  style={{ height: `${i * 4 + 4}px` }}
                />
              ))}
            </div>
            <span className="text-white text-xs">Boa conexão</span>
          </div>

          {/* Encryption Badge */}
          <div className="absolute top-4 right-4 flex items-center gap-2 bg-black/50 rounded-full px-3 py-1.5">
            <Shield className="w-4 h-4 text-secondary" />
            <span className="text-white text-xs">Chamada criptografada</span>
          </div>
        </div>

        {/* Chat Panel */}
        {showChat && (
          <div className="w-80 bg-white border-l border-slate-200 flex flex-col">
            <div className="p-4 border-b border-slate-200 flex items-center justify-between">
              <h3 className="font-semibold text-slate-900">Chat</h3>
              <button 
                onClick={() => setShowChat(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {chatMessages.length === 0 ? (
                <div className="text-center text-slate-400 text-sm py-8">
                  <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p>Nenhuma mensagem ainda</p>
                </div>
              ) : (
                chatMessages.map(msg => (
                  <div key={msg.id} className="bg-slate-100 rounded-lg p-3">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium text-sm text-slate-800">{msg.sender}</span>
                      <span className="text-xs text-slate-400">{msg.time}</span>
                    </div>
                    <p className="text-sm text-slate-600">{msg.text}</p>
                  </div>
                ))
              )}
            </div>

            {/* Input */}
            <div className="p-4 border-t border-slate-200">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  placeholder="Digite uma mensagem..."
                  className="flex-1 px-3 py-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50"
                />
                <Button size="sm" onClick={handleSendMessage}>
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Info Panel */}
        {showInfo && (
          <div className="absolute right-0 top-16 bottom-20 w-80 bg-white border-l border-slate-200 overflow-y-auto">
            <div className="p-6 space-y-6">
              <div>
                <h3 className="font-semibold text-slate-900 mb-4 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-primary" />
                  Prontuário Rápido
                </h3>
                
                <div className="space-y-4">
                  <div className="p-4 rounded-xl bg-slate-50">
                    <div className="flex items-center gap-3 mb-3">
                      <Avatar name={patientData.name} size="lg" />
                      <div>
                        <p className="font-semibold text-slate-900">{patientData.name}</p>
                        <p className="text-sm text-slate-500">Paciente</p>
                      </div>
                    </div>
                  </div>

                  <div>
                    <p className="text-sm font-medium text-slate-700 mb-2 flex items-center gap-2">
                      <Activity className="w-4 h-4 text-warning" />
                      Condições
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {patientData.conditions.map(c => (
                        <Badge key={c} variant="warning">{c}</Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <p className="text-sm font-medium text-slate-700 mb-2 flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-error" />
                      Alergias
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {patientData.allergies.map(a => (
                        <Badge key={a} variant="error">{a}</Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <p className="text-sm font-medium text-slate-700 mb-2 flex items-center gap-2">
                      <Pill className="w-4 h-4 text-secondary" />
                      Medicamentos em uso
                    </p>
                    <ul className="space-y-1">
                      {patientData.medications.map(m => (
                        <li key={m} className="text-sm text-slate-600 flex items-center gap-2">
                          <div className="w-1.5 h-1.5 rounded-full bg-secondary" />
                          {m}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100">
                <Button fullWidth variant="secondary">
                  <FileText className="w-4 h-4" />
                  Ver Prontuário Completo
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}