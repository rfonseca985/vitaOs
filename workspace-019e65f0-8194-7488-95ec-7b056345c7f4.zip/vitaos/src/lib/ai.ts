import OpenAI from 'openai';
import { prisma } from './db';

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// System prompts for different AI assistants
const PATIENT_SYSTEM_PROMPT = `Você é a vitasAI, assistente de saúde virtual do vitaOS. 

Sua missão é:
1. Ajudar pacientes com triagem de sintomas
2. Fornecer informações sobre saúde e bem-estar
3. Orientar sobre quando procurar atendimento médico
4. Auxiliar no agendamento de consultas
5. Acompanhar pós-consulta

IMPORTANTE:
- Você NÃO substitui advice médico profissional
- Sempre recomende consultar um médico para diagnósticos
- Seja empática e acolhedora
- Use linguagem simples e acessível
- Para emergências, oriente buscar atendimento imediato

Responda em português brasileiro de forma clara e humanizada. Use emojis com moderação para deixar a conversa mais amigável.`;

const DOCTOR_SYSTEM_PROMPT = `Você é a vitasAI Professional, assistente de IA para médicos do vitaOS.

Sua missão é:
1. Auxiliar no diagnóstico diferencial
2. Sugerir exames complementares
3. Fornecer informações sobre medicamentos e interações
4. Consultar protocolos clínicos
5. Auxiliar na redação de prontuário

IMPORTANTE:
- Você é uma ferramenta de apoio, não substitui julgamento clínico
- Sempre cite fontes quando possível
- Mantenha profissionalismo médico
- Respeite ética médica e privacidade do paciente

Use terminology médica apropriada. Responda de forma concisa e objetiva.`;

// Chat with AI
export async function chatWithAI(
  messages: Array<{ role: 'user' | 'assistant' | 'system'; content: string }>,
  userId: string,
  userRole: 'PATIENT' | 'DOCTOR' | 'ADMIN'
): Promise<string> {
  try {
    // Get user's medical context if exists
    let userContext = '';
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: {
        patient: true,
        doctor: true,
      },
    });

    if (user?.patient) {
      userContext = `
Contexto do paciente:
- Condições: ${user.patient.conditions.join(', ') || 'Nenhuma'}
- Alergias: ${user.patient.allergies.join(', ') || 'Nenhuma'}
- Medicamentos em uso: ${user.patient.medications.join(', ') || 'Nenhum'}
`;
    }

    const systemPrompt = userRole === 'DOCTOR' ? DOCTOR_SYSTEM_PROMPT : PATIENT_SYSTEM_PROMPT;
    
    const response = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        { role: 'system', content: systemPrompt + userContext },
        ...messages,
      ],
      temperature: 0.7,
      max_tokens: 1000,
    });

    return response.choices[0]?.message?.content || 'Desculpe, não consegui processar sua mensagem.';
  } catch (error) {
    console.error('OpenAI API Error:', error);
    return 'Desculpe, estou com dificuldades para responder agora. Tente novamente em alguns instantes.';
  }
}

// Symptom checker
export async function analyzeSymptoms(
  symptoms: string[],
  additionalInfo: Record<string, any>,
  userId: string
): Promise<{
  possibleConditions: string[];
  urgencyLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'EMERGENCY';
  recommendations: string[];
  shouldSeeDoctor: boolean;
  specialistRecommendation: string;
}> {
  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        {
          role: 'system',
          content: `Você é um assistente de triagem médica. Analise os sintomas e forneça:
1. Possíveis condições (máximo 5, em ordem de probabilidade)
2. Nível de urgência (LOW, MEDIUM, HIGH, EMERGENCY)
3. Recomendações iniciais
4. Se deve procurar médico
5. Qual especialista recomendar

Responda em JSON com apenas esses campos:
{
  "possibleConditions": [...],
  "urgencyLevel": "...",
  "recommendations": [...],
  "shouldSeeDoctor": true/false,
  "specialistRecommendation": "..."
}

IMPORTANTE: Isso é apenas triagem, não diagnóstico. Sempre mencione isso.`,
        },
        {
          role: 'user',
          content: `Sintomas: ${symptoms.join(', ')}
Informações adicionais: ${JSON.stringify(additionalInfo)}`,
        },
      ],
      response_format: { type: 'json_object' },
    });

    const content = response.choices[0]?.message?.content;
    if (content) {
      return JSON.parse(content);
    }
    
    return {
      possibleConditions: [],
      urgencyLevel: 'MEDIUM',
      recommendations: ['Consulte um médico para avaliação completa.'],
      shouldSeeDoctor: true,
      specialistRecommendation: 'Clínico Geral',
    };
  } catch (error) {
    console.error('Symptom analysis error:', error);
    return {
      possibleConditions: [],
      urgencyLevel: 'MEDIUM',
      recommendations: ['Erro ao analisar sintomas. Consulte um médico.'],
      shouldSeeDoctor: true,
      specialistRecommendation: 'Clínico Geral',
    };
  }
}

// Generate appointment summary
export async function generateAppointmentSummary(
  appointmentId: string
): Promise<string> {
  try {
    const appointment = await prisma.appointment.findUnique({
      where: { id: appointmentId },
      include: {
        patient: { include: { user: true } },
        doctor: { include: { user: true } },
        medicalRecords: true,
      },
    });

    if (!appointment) return 'Consulta não encontrada.';

    const response = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        {
          role: 'system',
          content: 'Você é um assistente médico que gera resumos de consultas. Forneça um resumo profissional e objetivo.',
        },
        {
          role: 'user',
          content: `
Gere um resumo da seguinte consulta:

Paciente: ${appointment.patient.user.name}
Médico: ${appointment.doctor.user.name}
Data: ${appointment.scheduledAt}
Tipo: ${appointment.type}

Prontuário do paciente:
${appointment.medicalRecords.map(r => `- ${r.title}: ${r.content}`).join('\n')}

Notas do médico:
${appointment.doctorNotes || 'Não há notas adicionais.'}

Forneça um resumo estruturado com:
1. Resumo da consulta
2. Diagnóstico
3. Tratamento prescrito
4. Orientações ao paciente
5. Próximo acompanhamento
`,
        },
      ],
    });

    return response.choices[0]?.message?.content || 'Resumo não disponível.';
  } catch (error) {
    console.error('Summary generation error:', error);
    return 'Erro ao gerar resumo.';
  }
}

// Check medication interactions
export async function checkMedicationInteractions(
  medications: string[]
): Promise<{
  hasInteractions: boolean;
  interactions: Array<{ medications: string[]; severity: string; description: string }>;
  recommendations: string[];
}> {
  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        {
          role: 'system',
          content: `Você é um farmacêutico clínico virtual. Analise interações medicamentosas.

Responda em JSON:
{
  "hasInteractions": true/false,
  "interactions": [{ "medications": [...], "severity": "...", "description": "..." }],
  "recommendations": [...]
}`,
        },
        {
          role: 'user',
          content: `Analise interações entre: ${medications.join(', ')}`,
        },
      ],
      response_format: { type: 'json_object' },
    });

    const content = response.choices[0]?.message?.content;
    if (content) {
      return JSON.parse(content);
    }

    return { hasInteractions: false, interactions: [], recommendations: [] };
  } catch (error) {
    console.error('Medication interaction check error:', error);
    return { hasInteractions: false, interactions: [], recommendations: [] };
  }
}

// Save AI conversation
export async function saveAIConversation(
  userId: string,
  messages: Array<{ role: 'user' | 'assistant' | 'system'; content: string }>
): Promise<void> {
  try {
    await prisma.conversation.updateMany({
      where: { userId, isAiConversation: true },
      data: {
        updatedAt: new Date(),
      },
    });
  } catch (error) {
    console.error('Failed to save AI conversation:', error);
  }
}