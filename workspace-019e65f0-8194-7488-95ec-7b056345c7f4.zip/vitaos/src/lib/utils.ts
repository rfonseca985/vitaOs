import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: Date | string, locale: string = 'pt-BR'): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleDateString(locale, {
    day: '2-digit',
    month: 'long',
    year: 'numeric',
  });
}

export function formatDateTime(date: Date | string, locale: string = 'pt-BR'): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleString(locale, {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function formatTime(date: Date | string, locale: string = 'pt-BR'): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleTimeString(locale, {
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function formatRelativeTime(date: Date | string): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  const now = new Date();
  const diff = now.getTime() - d.getTime();
  
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);
  
  if (minutes < 1) return 'agora';
  if (minutes < 60) return `${minutes}min atrás`;
  if (hours < 24) return `${hours}h atrás`;
  if (days < 7) return `${days}d atrás`;
  
  return formatDate(d);
}

export function formatCurrency(value: number, currency: string = 'BRL'): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency,
  }).format(value);
}

export function generateId(): string {
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
}

export function truncate(str: string, length: number): string {
  if (str.length <= length) return str;
  return str.substring(0, length) + '...';
}

export function capitalize(str: string): string {
  return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
}

export function slugify(str: string): string {
  return str
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

export function validateEmail(email: string): boolean {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

export function validateCPF(cpf: string): boolean {
  cpf = cpf.replace(/[^\d]/g, '');
  if (cpf.length !== 11) return false;
  if (/^(\d)\1{10}$/.test(cpf)) return false;
  
  let sum = 0;
  for (let i = 0; i < 9; i++) {
    sum += parseInt(cpf.charAt(i)) * (10 - i);
  }
  let remainder = (sum * 10) % 11;
  if (remainder !== parseInt(cpf.charAt(9))) return false;
  
  sum = 0;
  for (let i = 0; i < 10; i++) {
    sum += parseInt(cpf.charAt(i)) * (11 - i);
  }
  remainder = (sum * 10) % 11;
  return remainder === parseInt(cpf.charAt(10));
}

export function validateCRM(crm: string): boolean {
  return /^\d{4,8}$/.test(crm.replace(/[^0-9]/g, ''));
}

export function getInitials(name: string): string {
  return name
    .split(' ')
    .map(n => n[0])
    .join('')
    .toUpperCase()
    .substring(0, 2);
}

export function timeAgo(date: Date | string): string {
  const seconds = Math.floor((new Date().getTime() - new Date(date).getTime()) / 1000);
  
  const intervals = {
    ano: 31536000,
    mês: 2592000,
    semana: 604800,
    dia: 86400,
    hora: 3600,
    minuto: 60,
  };
  
  for (const [unit, secondsInUnit] of Object.entries(intervals)) {
    const interval = Math.floor(seconds / secondsInUnit);
    if (interval >= 1) {
      return `há ${interval} ${interval === 1 ? unit : unit + 's'}`;
    }
  }
  
  return 'agora';
}

export function getWeekDays(): string[] {
  return ['domingo', 'segunda', 'terça', 'quarta', 'quinta', 'sexta', 'sábado'];
}

export function getTimeSlots(start: string = '08:00', end: string = '18:00', interval: number = 30): string[] {
  const slots: string[] = [];
  const [startHour, startMin] = start.split(':').map(Number);
  const [endHour, endMin] = end.split(':').map(Number);
  
  let current = startHour * 60 + startMin;
  const endTime = endHour * 60 + endMin;
  
  while (current < endTime) {
    const hours = Math.floor(current / 60);
    const minutes = current % 60;
    slots.push(`${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`);
    current += interval;
  }
  
  return slots;
}

export function isTimeAvailable(scheduledAt: Date, duration: number, existingAppointments: Date[], startOfDay: Date, endOfDay: Date): boolean {
  const appointmentStart = scheduledAt.getTime();
  const appointmentEnd = appointmentStart + duration * 60000;
  
  // Check if within working hours
  const startTime = startOfDay.getTime() + 8 * 3600000; // 8 AM
  const endTime = endOfDay.getTime() + 18 * 3600000; // 6 PM
  
  if (appointmentStart < startTime || appointmentEnd > endTime) {
    return false;
  }
  
  // Check for conflicts with existing appointments
  for (const existing of existingAppointments) {
    const existingStart = existing.getTime();
    const existingEnd = existingStart + 30 * 60000; // Assume 30 min duration
    
    if (appointmentStart < existingEnd && appointmentEnd > existingStart) {
      return false;
    }
  }
  
  return true;
}

// Specialty icons mapping
export const SPECIALTY_ICONS: Record<string, string> = {
  'Clínica Geral': 'stethoscope',
  'Cardiologia': 'heart',
  'Dermatologia': 'sparkles',
  'Endocrinologia': 'activity',
  'Gastroenterologia': 'stomach',
  'Neurologia': 'brain',
  'Ortopedia': 'bone',
  'Oftalmologia': 'eye',
  'Pediatria': 'baby',
  'Psiquiatria': 'brain',
  'Ginecologia': 'heart-pulse',
  'Urologia': 'droplets',
  'default': 'user',
};

// Medical conditions quick list
export const COMMON_CONDITIONS = [
  'Diabetes',
  'Hipertensão',
  'Asma',
  'Artrite',
  'Depressão',
  'Ansiedade',
  'Hipotireoidismo',
  'Osteoporose',
  'Bronquite',
  'Alergias',
];

// Common allergies
export const COMMON_ALLERGIES = [
  'Penicilina',
  'Dipirona',
  'AAS / Aspirina',
  'Ibuprofeno',
  'Latex',
  'Frutos do mar',
  'Glúten',
  'Lactose',
];

// Blood types
export const BLOOD_TYPES = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

// Brazilian states for CRM
export const BRAZILIAN_STATES = [
  'AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA',
  'MT', 'MS', 'MG', 'PA', 'PB', 'PR', 'PE', 'PI', 'RJ', 'RN',
  'RS', 'RO', 'RR', 'SC', 'SP', 'SE', 'TO',
];