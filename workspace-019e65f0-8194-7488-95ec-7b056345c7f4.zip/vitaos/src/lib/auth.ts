import { cookies } from 'next/headers';
import { prisma } from './db';
import { compare, hash } from 'bcryptjs';

export async function hashPassword(password: string): Promise<string> {
  return hash(password, 12);
}

export async function verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
  return compare(password, hashedPassword);
}

export async function getUserFromSession(): Promise<{ id: string; email: string; role: string } | null> {
  try {
    const cookieStore = await cookies();
    const sessionCookie = cookieStore.get('vitaos_session');
    
    if (!sessionCookie?.value) {
      return null;
    }

    // Decode session (in production, use proper JWT)
    const decoded = Buffer.from(sessionCookie.value, 'base64').toString('utf-8');
    const [userId, timestamp] = decoded.split(':');
    
    // Session expires after 7 days
    const sevenDays = 7 * 24 * 60 * 60 * 1000;
    if (Date.now() - parseInt(timestamp) > sevenDays) {
      return null;
    }

    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { id: true, email: true, role: true },
    });

    return user;
  } catch {
    return null;
  }
}

export async function createSession(userId: string): Promise<string> {
  const sessionData = `${userId}:${Date.now()}`;
  return Buffer.from(sessionData).toString('base64');
}

export function generateSecureToken(length: number = 32): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let token = '';
  for (let i = 0; i < length; i++) {
    token += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return token;
}

export function validateSessionToken(token: string): boolean {
  try {
    const decoded = Buffer.from(token, 'base64').toString('utf-8');
    const parts = decoded.split(':');
    return parts.length === 2 && parts[0].length > 0 && !isNaN(parseInt(parts[1]));
  } catch {
    return false;
  }
}