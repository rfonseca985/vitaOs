import { create } from 'zustand';
import { User, DoctorProfile, PatientProfile, Appointment, Conversation, Notification } from '@/types';

interface AuthState {
  user: User | null;
  doctor: DoctorProfile | null;
  patient: PatientProfile | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  setUser: (user: User | null) => void;
  setDoctor: (doctor: DoctorProfile | null) => void;
  setPatient: (patient: PatientProfile | null) => void;
  setLoading: (loading: boolean) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  doctor: null,
  patient: null,
  isLoading: true,
  isAuthenticated: false,
  
  setUser: (user) => set({ 
    user, 
    isAuthenticated: !!user,
    isLoading: false 
  }),
  
  setDoctor: (doctor) => set({ doctor }),
  setPatient: (patient) => set({ patient }),
  setLoading: (isLoading) => set({ isLoading }),
  
  logout: () => set({ 
    user: null, 
    doctor: null, 
    patient: null, 
    isAuthenticated: false 
  }),
}));

interface AppointmentState {
  appointments: Appointment[];
  currentAppointment: Appointment | null;
  isLoading: boolean;
  setAppointments: (appointments: Appointment[]) => void;
  setCurrentAppointment: (appointment: Appointment | null) => void;
  addAppointment: (appointment: Appointment) => void;
  updateAppointment: (id: string, updates: Partial<Appointment>) => void;
  setLoading: (loading: boolean) => void;
}

export const useAppointmentStore = create<AppointmentState>((set) => ({
  appointments: [],
  currentAppointment: null,
  isLoading: false,
  
  setAppointments: (appointments) => set({ appointments }),
  setCurrentAppointment: (currentAppointment) => set({ currentAppointment }),
  
  addAppointment: (appointment) => set((state) => ({
    appointments: [appointment, ...state.appointments],
  })),
  
  updateAppointment: (id, updates) => set((state) => ({
    appointments: state.appointments.map((a) => 
      a.id === id ? { ...a, ...updates } : a
    ),
  })),
  
  setLoading: (isLoading) => set({ isLoading }),
}));

interface ChatState {
  conversations: Conversation[];
  currentConversation: Conversation | null;
  unreadCount: number;
  setConversations: (conversations: Conversation[]) => void;
  setCurrentConversation: (conversation: Conversation | null) => void;
  addConversation: (conversation: Conversation) => void;
  updateConversation: (id: string, updates: Partial<Conversation>) => void;
  setUnreadCount: (count: number) => void;
  incrementUnread: () => void;
}

export const useChatStore = create<ChatState>((set) => ({
  conversations: [],
  currentConversation: null,
  unreadCount: 0,
  
  setConversations: (conversations) => set({ conversations }),
  setCurrentConversation: (currentConversation) => set({ currentConversation }),
  
  addConversation: (conversation) => set((state) => ({
    conversations: [conversation, ...state.conversations],
  })),
  
  updateConversation: (id, updates) => set((state) => ({
    conversations: state.conversations.map((c) => 
      c.id === id ? { ...c, ...updates } : c
    ),
  })),
  
  setUnreadCount: (count) => set({ unreadCount: count }),
  incrementUnread: () => set((state) => ({ unreadCount: state.unreadCount + 1 })),
}));

interface NotificationState {
  notifications: Notification[];
  unreadCount: number;
  setNotifications: (notifications: Notification[]) => void;
  addNotification: (notification: Notification) => void;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  setUnreadCount: (count: number) => void;
}

export const useNotificationStore = create<NotificationState>((set) => ({
  notifications: [],
  unreadCount: 0,
  
  setNotifications: (notifications) => set({ notifications }),
  
  addNotification: (notification) => set((state) => ({
    notifications: [notification, ...state.notifications],
    unreadCount: state.unreadCount + 1,
  })),
  
  markAsRead: (id) => set((state) => ({
    notifications: state.notifications.map((n) => 
      n.id === id ? { ...n, isRead: true, readAt: new Date() } : n
    ),
    unreadCount: Math.max(0, state.unreadCount - 1),
  })),
  
  markAllAsRead: () => set((state) => ({
    notifications: state.notifications.map((n) => ({ ...n, isRead: true, readAt: new Date() })),
    unreadCount: 0,
  })),
  
  setUnreadCount: (count) => set({ unreadCount: count }),
}));

interface UIState {
  sidebarOpen: boolean;
  modalOpen: string | null;
  toasts: Array<{ id: string; type: string; message: string }>;
  toggleSidebar: () => void;
  setSidebarOpen: (open: boolean) => void;
  openModal: (modalId: string) => void;
  closeModal: () => void;
  addToast: (type: string, message: string) => void;
  removeToast: (id: string) => void;
}

export const useUIStore = create<UIState>((set) => ({
  sidebarOpen: true,
  modalOpen: null,
  toasts: [],
  
  toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),
  setSidebarOpen: (sidebarOpen) => set({ sidebarOpen }),
  
  openModal: (modalOpen) => set({ modalOpen }),
  closeModal: () => set({ modalOpen: null }),
  
  addToast: (type, message) => set((state) => ({
    toasts: [...state.toasts, { id: Date.now().toString(), type, message }],
  })),
  
  removeToast: (id) => set((state) => ({
    toasts: state.toasts.filter((t) => t.id !== id),
  })),
}));

// Video call state
interface VideoCallState {
  isInCall: boolean;
  roomUrl: string | null;
  roomToken: string | null;
  isMuted: boolean;
  isVideoOff: boolean;
  participants: Array<{ id: string; name: string; isMuted: boolean; isVideoOff: boolean }>;
  startCall: (roomUrl: string, roomToken: string) => void;
  endCall: () => void;
  toggleMute: () => void;
  toggleVideo: () => void;
}

export const useVideoCallStore = create<VideoCallState>((set) => ({
  isInCall: false,
  roomUrl: null,
  roomToken: null,
  isMuted: false,
  isVideoOff: false,
  participants: [],
  
  startCall: (roomUrl, roomToken) => set({ 
    isInCall: true, 
    roomUrl, 
    roomToken,
    isMuted: false,
    isVideoOff: false,
  }),
  
  endCall: () => set({ 
    isInCall: false, 
    roomUrl: null, 
    roomToken: null,
    participants: [],
  }),
  
  toggleMute: () => set((state) => ({ isMuted: !state.isMuted })),
  toggleVideo: () => set((state) => ({ isVideoOff: !state.isVideoOff })),
}));