// User types
export type UserRole = 'PATIENT' | 'DOCTOR' | 'ADMIN';

export interface User {
  id: string;
  email: string;
  role: UserRole;
  name: string;
  phone?: string | null;
  avatar?: string | null;
  dateOfBirth?: Date | null;
  cpf?: string | null;
  isVerified: boolean;
  isActive: boolean;
  lastLoginAt?: Date | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface DoctorProfile {
  id: string;
  userId: string;
  user: User;
  crm: string;
  crmState: string;
  specialty: string;
  specialtyId?: string | null;
  bio?: string | null;
  education?: string | null;
  consultationPrice: number;
  consultationCurrency: string;
  consultationDuration: number;
  availability?: Record<string, string[]> | null;
  rating: number;
  reviewCount: number;
  totalConsultations: number;
  documentsVerified: boolean;
  verifiedAt?: Date | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface PatientProfile {
  id: string;
  userId: string;
  user: User;
  emergencyContact?: string | null;
  emergencyPhone?: string | null;
  bloodType?: string | null;
  allergies: string[];
  conditions: string[];
  medications: string[];
  surgeries: string[];
  hasInsurance: boolean;
  insuranceProvider?: string | null;
  insuranceNumber?: string | null;
  totalConsultations: number;
  createdAt: Date;
  updatedAt: Date;
}

// Appointment types
export type AppointmentStatus = 'SCHEDULED' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED';
export type AppointmentType = 'VIDEO' | 'CHAT' | 'PHONE';

export interface Appointment {
  id: string;
  patientId: string;
  patient: User;
  doctorId: string;
  doctor: User & { doctor?: DoctorProfile };
  scheduledAt: Date;
  duration: number;
  status: AppointmentStatus;
  type: AppointmentType;
  roomUrl?: string | null;
  roomToken?: string | null;
  patientNotes?: string | null;
  doctorNotes?: string | null;
  summary?: string | null;
  followUpDate?: Date | null;
  createdAt: Date;
  updatedAt: Date;
}

// Message types
export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  sender: User;
  content: string;
  type: string;
  isRead: boolean;
  readAt?: Date | null;
  createdAt: Date;
}

export interface Conversation {
  id: string;
  userId: string;
  user?: User;
  doctorId?: string | null;
  patientId?: string | null;
  appointmentId?: string | null;
  isAiConversation: boolean;
  context?: Record<string, any> | null;
  lastMessageAt: Date;
  createdAt: Date;
  updatedAt: Date;
  messages?: Message[];
}

// Medical Record types
export interface MedicalRecord {
  id: string;
  patientId: string;
  patient?: PatientProfile;
  doctorId?: string | null;
  doctor?: User;
  appointmentId?: string | null;
  type: string;
  title: string;
  content: string;
  attachments: Array<{ name: string; url: string; type: string }>;
  isShared: boolean;
  createdAt: Date;
  updatedAt: Date;
}

// Prescription types
export interface Prescription {
  id: string;
  appointmentId: string;
  appointment?: Appointment;
  doctorId: string;
  doctor?: DoctorProfile;
  patientId: string;
  patient?: PatientProfile;
  medications: Array<{
    name: string;
    dosage: string;
    frequency: string;
    duration: string;
    instructions: string;
  }>;
  instructions?: string | null;
  validUntil: Date;
  qrCode?: string | null;
  isUsed: boolean;
  usedAt?: Date | null;
  createdAt: Date;
  updatedAt: Date;
}

// AI Chat types
export interface AIConversation {
  id: string;
  userId: string;
  context: {
    symptoms?: string[];
    conditions?: string[];
    medications?: string[];
    lastTopics?: string[];
  };
  messages: Array<{
    role: 'user' | 'assistant' | 'system';
    content: string;
    timestamp: Date;
  }>;
  createdAt: Date;
  updatedAt: Date;
}

// Specialty types
export interface Specialty {
  id: string;
  name: string;
  description?: string | null;
  icon?: string | null;
  createdAt: Date;
}

// API Response types
export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

export interface PaginatedResponse<T> extends ApiResponse<T[]> {
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

// Form types
export interface LoginFormData {
  email: string;
  password: string;
  rememberMe?: boolean;
}

export interface RegisterFormData {
  email: string;
  password: string;
  confirmPassword: string;
  name: string;
  phone: string;
  dateOfBirth: string;
  cpf: string;
  role: UserRole;
  // Doctor specific
  crm?: string;
  crmState?: string;
  specialty?: string;
}

export interface AppointmentFormData {
  doctorId: string;
  scheduledAt: string;
  duration: number;
  type: AppointmentType;
  patientNotes?: string;
}

// Dashboard types
export interface DashboardStats {
  totalAppointments: number;
  upcomingAppointments: number;
  completedAppointments: number;
  totalDoctors: number;
  totalPatients: number;
}

// Notification types
export interface Notification {
  id: string;
  userId: string;
  type: string;
  title: string;
  message: string;
  data?: Record<string, any>;
  isRead: boolean;
  readAt?: Date | null;
  createdAt: Date;
}